<div class="user">
	<p>Administrator</p>
	<a class="logout_user" href="<?php echo base_url()?>auth/logout" title="Logout">Logout</a>
</div>