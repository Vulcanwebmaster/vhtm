<header>
        <h1><a href="index.html"><img src="<?php echo base_url();?>assets/tuongnhat/images/logo.png" alt=""></a></h1>
        <nav>  
            <ul class="menu">
                <li class="current"><a href="<?php echo base_url();?>">Trang chủ</a></li>
                <li><a href="#">Giới thiệu</a></li>
                <li><a href="#">Du học</a></li>
                <li class="menuitem"><a href="#" id="thuongmai-menu">Thương mại</a>
                	<fieldset class="level2">
                		<ul>
                			<li><a href="#">Tường Nhật Bakery</a></li>
                		</ul>
                	</fieldset>
                </li>
				<li><a href="#">Dịch vụ</a></li>
				<li><a href="#">Liên hệ</a></li>
				<li><a href="#">Đối tác</a></li>
            </ul>
         </nav>
         <?php $this->load->view('front/slide.php');?>
    </header>