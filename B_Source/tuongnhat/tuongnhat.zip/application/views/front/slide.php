<div id="slide">		
				<div class="slider">
					<ul class="items">
						<li><img src="<?php echo base_url();?>assets/tuongnhat/images/slider-1.jpg" alt="" /><div class="banner"></div></li>
						<li><img src="<?php echo base_url();?>assets/tuongnhat/images/slider-2.jpg" alt="" /><div class="banner"></div></li>
						<li><img src="<?php echo base_url();?>assets/tuongnhat/images/slider-3.jpg" alt="" /><div class="banner"></div></li>
					</ul>
				</div>	
				<a href="#" class="prev"></a><a href="#" class="next"></a>
				<div class="line-left"></div>
				<div class="line-right"></div>
				<ul class="pags"></ul>
			 </div>