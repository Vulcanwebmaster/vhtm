<div id="footer">	
		<div class="group">	
			<div id="logofooter">
				<img alt="" src="<?php echo base_url();?>assets/tuongnhat/images/logofooter.png">
				<br>
				<img alt="" src="<?php echo base_url();?>assets/tuongnhat/images/cross-line.png">
			</div>
			<div class="footer-cat">
				<h3>Du học</h3>		
				<ul>
					<li>kensingtoncoll.ac.uk</li>	
					<li>Sự Kiện: Hội Thảo,</li><li>						
				</li></ul>
			</div>
			<div class="footer-cat">
				<h3>Thương mại</h3>
				<ul>
					<li>Quần dài</li>
					<li>Quần sooc</li><li>	
					</li><li>Áo sơ mi</li><li>						
					</li><li>Áo Phông</li><li>
					</li><li>Áo Khoác</li><li>
					</li><li>Giầy</li><li>					
				</li></ul>
			</div>
			<div class="footer-cat">
				<h3>Đối tác</h3>		
				<ul>
					<li>Microsoft</li>
					<li>Apple</li><li>	
					</li><li>NATO</li><li>
					</li><li>Dell</li><li>					
					</li><li>Asus</li><li>
					</li><li>Acer</li><li>					
				</li></ul>
			</div>
			
			<div class="footer-cat">	
				<h3>Dịch vụ</h3>
				<ul>
					<li>Phương thức chuyển hàng</li>
					<li>Bảng giá</li><li>				
				</li></ul>
			</div>
		</div>
		<div id="info-panel">
			<p>Copyright © 2012 <a href="http://niw.com.vn">NIW</a> Design. All Rights Reserved.</p>
		</div>
	</div>