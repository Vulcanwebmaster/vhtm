<section id="content"><div class="ic">More Website Templates @ TemplateMonster.com. May 14, 2012!</div>
			<div class="slogan">
				<p><span class="clr-1">Phục vụ</span> khách hàng với chất lượng dịch vụ tốt nhất</p>
				<p>Làm hài lòng quý vị là phương châm hoạt động của chúng tôi.</p>
				<a href="#" class="button-2">click here</a>
			</div>
			<div class="wrap page1-row1">
				<div class="box-1 border-right">
					<strong class="number number-1">01.</strong>
					<span class="text-1">Du học</span>
					<p class="text-2">Các thông tin về du học, học bổng du học. </p>
					<p class="text-3">Các bài viết về kinh nghiệm và thủ tục visa du học các nước</p>
					<a href="#" class="link-1">Xem thêm</a>
				</div>
				<div class="box-1 border-right">
					<strong class="number number-2">02.</strong>
					<span class="text-1">Thương mại</span>
					<p class="text-2">Nổi bật với thời trang Tường Nhật</p>
					<p class="text-3">Những mẫu mã mới, đa phong cách, cập nhật 24/24</p>
					<a href="#" class="link-1">Xem thêm</a>
				</div>
				<div class="box-1 border-right">
					<strong class="number number-3">03.</strong>
					<span class="text-1">Dịch vụ</span>
					<p class="text-2">Những dịch vụ tận tình, chu đáo của Tường Nhật</p>
					<p class="text-3">Dịch vụ chuyển hàng hóa theo đường hàng không.</p>
					<a href="#" class="link-1">Xem thêm</a>
				</div>
				<div class="box-1 last">
					<strong class="number number-4">04.</strong>
					<span class="text-1">Đối tác</span>
					<p class="text-2">Các đối tác chiến lược</p>
					<p class="text-3">Những khách hàng đã tin tưởng và hợp tác cùng Tường Nhật</p>
					<a href="#" class="link-1">Xem thêm</a>
				</div>
			</div>
			<div class="wrap page1-row2">				
				<div class="wrap">
				  <div class="aside-col-1 border-right-2">
						<h3><span class="clr-1">Đ</span>ăng ký:</h3>
						<form id="form-search" method="post">
						  <span>Nhập địa chỉ email:</span>
						  <input type="text" value="" onBlur="if(this.value=='') this.value=''" onFocus="if(this.value =='' ) this.value=''"  />
						  <a href="#" onClick="document.getElementById('form-search').submit()" class="link-2">Đăng ký</a>
						</form>
					</div>
					<div class="aside-col-2 border-right-2">
						<h3><span class="clr-1">L</span>ưu ý:</h3>
						<p>Chúng tôi sẽ gửi thông báo tới hòm thư mà bạn đăng ký. Vì vậy hãy nhập chính xác địa chỉ email vì quyền lợi của bạn. </p>
					</div>  
					<div class="aside-col-3 border-right-2">
						<dl class="adrss">
							<dd><span>ĐT 1:</span><strong>+1 800 559 6580</strong></dd>
							<dd><span>ĐT 2:</span><strong>+1 800 603 6035</strong></dd>
							<dd><span>Fax:</span><strong>+1 800 889 9898</strong></dd>
							<dd><span>E-mail:</span><a href="#" class="link"><strong>hr@niw.com.vn</strong></a></dd>
						</dl> 
						<p><strong>P1902-CT5B-Mễ Trì Thượng-Từ Liêm - Hà Nội</strong></p>
					</div>  
					<div class="aside-col-4">
						<div class="soc-icons">
							<a href="#"><img src="<?php echo base_url();?>assets/tuongnhat/images/icon-1.png" alt=""></a>
							<a href="#"><img src="<?php echo base_url();?>assets/tuongnhat/images/icon-2.png" alt=""></a>
							<a href="#"><img src="<?php echo base_url();?>assets/tuongnhat/images/icon-3.png" alt=""></a>
						</div>
					</div>  
				</div>
			</div>
		</section>