</header>
<div id="content"><!--<div class="ic">More Website Templates @ TemplateMonster.com. May 14, 2012!</div>-->
        <div class="slogan top-1">
        	<p>Chúng tôi <span class="clr-1">cung cấp</span> cho bạn <span class="clr-1">những</span>  dịch vụ <span class="clr-1">tốt nhất</span></p>
            <p>Làm hài lòng quý vị là phương châm hoạt động của chúng tôi.</p>
            <a href="#" class="button-2">click here</a>
        </div>
        <div class="wrap page2-row1">
        	<div class="page2-col-1 border-right">
            	<h2><span class="clr-1">Tại </span>sao là chúng tôi?</h2>
                <ul class="list-1">
                	<li><a href="#">Lorem ipsum</a></li>
                    <li><a href="#">Consectetur elit</a></li>
                    <li><a href="#">Vivamus sed a</a></li>
                    <li><a href="#">Ivamus hendrerit</a></li>
                    <li><a href="#">Gravida viverra</a></li>
                    <li><a href="#">Cras mattis</a></li>
                </ul>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sed arcu dui, eu tincidunt sem vivamus.</p>
            </div> 
            <div class="page2-col-2 border-right">
            	<h2><span class="clr-1">Chúng </span>tôi là ai?</h2>
                <div class="wrap">
                	<img src="<?php echo base_url();?>assets/tuongnhat/images/page2-img1.jpg" alt="" class="img-indent-2 img-border">
                    <p class=" extra-wrap"><strong class="clr-2">Kensington College of Business (KCB)</strong> <br>
 là một trong những trường Cao Đẳng đầu tiên được phép đào tạo các khóa Đại Học ở Anh và năm 2007 trường đã vinh dự tổ chức kỷ niệm 25 năm kể từ ngày thành lập. </p>
                </div>
                <p><strong> KCB là trường duy nhất ở Anh được tham gia vào ba lĩnh vực giảng dạy:</strong><br>Dự Bị Đại Học, Đại Học và Cao Học, Đây là nơi cung cấp nguồn lao động dồi dào và tay nghề chuyên môn cho một số ngân hàng, các công ty và một số các tập đoàn lớn ở Anh cũng như nhiều nước trên thế giới. Trường cũng trang bị cho sinh viên bằng cấp tay nghề hàng đầu như (Chartered Professional bodies), Institute of Chartered Secretaries and Administrators  (ICSA) và Viện Tiếp Thị (Chartered Institute of Marketing - CIM). Một số các sáng kiến hợp tác với các cơ quan đã được độc quyền bởi KCB - độc quyền đào tạo các khóa học (Certificate in Company Secretarial Practice and Share Registration Practice – CCSP).<br>velit velit eu magna. </p>
                <a href="#" class="link-2">Xem thêm</a>
            </div>
            <div class="page2-col-3">
            	<h2><span class="clr-1">C</span>hứng nhận</h2>
                <div class="box-3">
                    <div class="comment">
                        <p><img src="<?php echo base_url();?>assets/tuongnhat/images/comment-top.png" alt="" >Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sed arcu dui, eu tincidunt sem vivamus.<img src="<?php echo base_url();?>assets/tuongnhat/images/comment-bottom.png" alt=""></p>
                        <span><strong>Tina Smith</strong> (top manager)</span>
                    </div>
                 </div>   
                 <div class="box-3">
                    <div class="comment">
                        <p><img src="<?php echo base_url();?>assets/tuongnhat/images/comment-top.png" alt="" >Vivamus sed arcu dui, eu tincidunt sem vivamus.
 hendrerit mauris ut dui gravida ut viverra lectus tincidunt. Cras mattis tempor eros.<img src="<?php echo base_url();?>assets/tuongnhat/images/comment-bottom.png" alt=""></p>
                        <span><strong>John Green</strong> (director)</span>
                    </div>
                </div>
                <a href="#" class="link-2">Xem thêm</a>
            </div>   
        </div>
        <div class="wrap page1-row2">				
				<div class="wrap">
				  <div class="aside-col-1 border-right-2">
						<h3><span class="clr-1">Đ</span>ăng ký:</h3>
						<form id="form-search" method="post">
						  <span>Nhập địa chỉ email:</span>
						  <input type="text" value="" onBlur="if(this.value=='') this.value=''" onFocus="if(this.value =='' ) this.value=''"  />
						  <a href="#" onClick="document.getElementById('form-search').submit()" class="link-2">Đăng ký</a>
						</form>
					</div>
					<div class="aside-col-2 border-right-2">
						<h3><span class="clr-1">L</span>ưu ý:</h3>
						<p>Chúng tôi sẽ gửi thông báo tới hòm thư mà bạn đăng ký. Vì vậy hãy nhập chính xác địa chỉ email vì quyền lợi của bạn. </p>
					</div>  
					<div class="aside-col-3 border-right-2">
						<dl class="adrss">
							<dd><span>ĐT 1:</span><strong>+1 800 559 6580</strong></dd>
							<dd><span>ĐT 2:</span><strong>+1 800 603 6035</strong></dd>
							<dd><span>Fax:</span><strong>+1 800 889 9898</strong></dd>
							<dd><span>E-mail:</span><a href="#" class="link"><strong>hr@niw.com.vn</strong></a></dd>
						</dl> 
						<p><strong>P1902-CT5B-Mễ Trì Thượng-Từ Liêm - Hà Nội</strong></p>
					</div>  
					<div class="aside-col-4">
						<div class="soc-icons">
							<a href="#"><img src="<?php echo base_url();?>assets/tuongnhat/images/icon-1.png" alt=""></a>
							<a href="#"><img src="<?php echo base_url();?>assets/tuongnhat/images/icon-2.png" alt=""></a>
							<a href="#"><img src="<?php echo base_url();?>assets/tuongnhat/images/icon-3.png" alt=""></a>
						</div>
					</div>  
				</div>
			</div>
    </div> 