<?php
/* 
 modules/webshop/language/english/kaimonokago
 */

$lang['test'] = "Test in en. This file is in modules/webshop/language/english/kaimonokago";
$lang['current_language'] = "English";


?>
