<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<SCRIPT type="text/javascript" language="JavaScript" src="<?php echo base_url();?>assets/js/admin/lib.js"></SCRIPT>
	<SCRIPT type="text/javascript" language="JavaScript" src="<?php echo base_url();?>assets/js/admin/exchange.js"></SCRIPT>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/admin/style.css" media="screen">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/admin/admin.css" media="screen">
	<TITLE>i-Stock Gold : Automatic currency exchange software</TITLE>
</head>
<body>

<div id="wrapper">
	<div id="header">
	<table height="65" border="0" cellpadding="0" cellspacing="0">
	<tr>
	  <td nowrap="nowrap"><h1><font color="#FFCC00">i-stockgold</font></h1></td>   
	</tr>
	</table>
	
	<table border="0" cellspacing="0" cellpadding="0" width="100%">
	    <tr>
	      <td width="9" background="<?php echo base_url();?>assets/images/admin/spacer.gif" width="9" height="60" /></td>
	      <td width="100%" height="157" background="<?php echo base_url();?>assets/images/admin/top_bg.gif" style="vertical-align:top">
		      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="<?php echo base_url();?>assets/images/admin/top_bg2.gif" style="margin-top:8px;">
		        <tr>
		          <td>&nbsp;</td>
		          <td width="100%" style="text-align:center; vertical-align:top;height:142px; text-align:left" ><img src="<?php echo base_url();?>assets/images/admin/logo.gif" alt="Auto-Exchanger Demo" vspace="11"/></td>         
		        </tr>
		      </table>
		  </td>
	      <td width="9" background="<?php echo base_url();?>assets/images/admin/top_right.gif"><img src="<?php echo base_url();?>assets/images/admin/spacer.gif" width="9" height="60" /></td>
	    </tr>
	
	</table>
	</div>