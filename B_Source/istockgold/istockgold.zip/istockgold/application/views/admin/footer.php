<div id="footer">
	<p class="menu">
		<p class="copyright">&copy;2012 , NIW,  All Rights Reserved.<br />
          <span style=display:none;>
          </span>
        </p>	
  </p>
</div>
</div>
</body>
</html>