<?php
$this->load->view($this->config->item('backendpro_template_public') . 'header');
$this->load->view($this->config->item('backendpro_template_public') . 'content');
$this->load->view($this->config->item('backendpro_template_public') . 'footer');
?>
