    <div id="footer">
    </div> 
</div>
<?php print $this->bep_assets->get_footer_assets();?>
</body>
</html>