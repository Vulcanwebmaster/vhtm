 <div id="header" class="main-fream">
            <div id="header-top">
                <img alt="" src="<?php echo base_url()?>assets/images/logo.png" style="float:left"/>                    
                <div style="float:left; font-family:Tahoma; color:#FF8040; margin-left:10px; margin-top:20px; font-weight:bold; font-size:16px">
                    <p>Instant e-currency exchange - Fast delivery - LowFee</p>
                </div>
                <div style="float:right">
                    <div style="margin-top:10px">
                        <img src="<?php echo base_url()?>assets/images/dola.png" alt="" style="float:left"/>
                        <p style="float:left; margin-top:2px; font-family:Tahoma; font-size:12px;color:Silver; margin-right:20px">
                        	<a href="<?php  echo site_url($module."/order");?>">Tracking my order</a> 
                        	|
                        	<a href="<?php  echo base_url()?>index.php/welcome/ouraccounts"> Our accounts </a>
                        	|
                        	<a href="<?php  echo base_url()?>index.php/welcome/faq"> FAQ </a>
                        	|
                        	<a href="<?php  echo base_url()?>index.php/welcome/contact"> Contact us</a>
                        </p>
                    </div>
                    <div style="padding-left:25px;padding-top:5px; clear:both">
                        <img alt="" src="<?php echo base_url()?>assets/images/customer service.jpg" />
                    </div>
                    <div align="right" style="margin-right:20px">
                        <select>                            
                            <option>
                                ENG                                                            
                            </option>
                            <option>VNI</option>
                        </select>
                    </div>
                </div>
            </div>
            <div id="header-bottom">
                <div id="header-bottom-center">
                    <img src="<?php echo base_url()?>assets/images/we exchange from.png" alt="" style="margin-top:30px"/>
                    <img src="<?php echo base_url()?>assets/images/western unio.jpg" alt="" style="margin-top:20px"/>
                    <img src="<?php echo base_url()?>assets/images/to.png" alt="" style="margin-top:35px; margin-left:35px"/>
                    <img src="<?php echo base_url()?>assets/images/Liberty Reserve.jpg" alt="" style="margin-top:15px; margin-left:30px; border:inset 1px silver"/>
                    <img src="<?php echo base_url()?>assets/images/lowest fee in the world.png" alt="" style="margin-top:35px; margin-left:30px"/>
                </div>
            </div>
        </div>
    <div id="header-line">        
</div>
   <!-- End of div header-->
