<div id="footer">
		<div>
			<a href = "<?php  echo base_url()?>" >Home</a>
			|
			<a>Reserves Notification</a>
			|
			<a>Exchange e-Currency</a>			
			|
			<a href = "<?php  echo base_url()?>index.php/welcome/faq">Faqs</a>
			|
			<a href = "<?php  echo site_url($module."/order");?>" >Track Order</a>
			|
			<a>News</a>
			|
			<a href = "<?php  echo base_url()?>index.php/welcome/contact" >Contact Us</a>
		</div> 
		<p>Copyright &copy 2011 Yahoo! Inc. All Rights Reserved.</p>
	</div><!-- END of FOOTER  -->
	