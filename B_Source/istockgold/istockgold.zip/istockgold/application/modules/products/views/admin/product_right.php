<h2>Product Categories Notes</h2>
    
<div class="basic" id="accordion">
    <a>Gallery 1 Class</a>
    <div>
        <h3>Class</h3>
	<p>You can add your information here. This is just an example.Class is used for sorting images <b>only in Galleri 1</b> at the moment. <br />Use the following class for grouping.
        <br />For example, input message-from-the-wee-folk.        </p>
        
            <p>new-flight: Book New Flight<br />
            det-hemmelige-eventyret: Det Hemmelige Eventyret<br />
            cumulus: Cumulus<br />
            messages-from-the-wee-fork: Message from the Wee Folk<br />
            wisdom-of-four-winds: Wisdom of four winds<br />
           amina: Amina</p>
            <h3>Image size:</h3>
            <h4>Thumb</h4>
            <p>
            width: 77px; height: 105px;</p>
             <h4>Big image</h4>
             <p>max width: 800px; max height: 800px</p>
    </div>
		
    <a>Web Design Gallerie</a>
    <div>
	<h3>Image Size</h3>
            <p>Thumb: width 150px<br />
           Big image: max width: 800px;</p>
           <p>Name will be in anchor title, <br />
           i.e. www.vitaveritas.no </p>
           <p>rel will be image rel,<br />
           i.e. imagebox-lights.</p>
           <p>shortdesc will be in alt in img and in anchor, <br />
           i.e. http://www.vitaveritas.no/.</p>
           <p>longdesc will be used as Plattform: Visma Avendo
nettbutikk 
           
            </p>
           <p>No class for web site gallery</p>
           <p>Grouping: use image-light</p>
            <p>Example: &lt;li&gt;&lt;a href="images/web/vitaveritas_b.jpg" rel="imagebox-lights" title="www.vitaveritas.no/" &gt;&lt;img src="images/web/vitaveritas.jpg" alt="www.vitaveritas.no/" width="150" height="97" /&gt;</a&gt;
&lt;a href="http://www.vitaveritas.no/" target="_blank">www.vitaveritas.no&lt;/a>&lt;br /&gt;
Plattform: Visma Avendo&lt;/li&gt;</p>
        
    </div>
		
    <a>Front Page Top</a>
    <div>
	<ul>
            <li>No plug-ins or system updates</li>
            <li>Browser based administration</li>
            <li>Unlimited products, categories</li>
            <li>Use as complete storefront</li>
            <li>Integrates into any existing web</li>
            <li>Free add-ons for gateways, languages and real-time shipping</li>
            <li>Turn on shopping features as you need them</li>
            <li>Simple shops can be up and running in an hour. Just add your products. </li>
        </ul>
    </div>
		
    <a>Front Page Bottom</a>
    <div>
	<ul>
            <li>No plug-ins or system updates</li>
            <li>Browser based administration</li>
            <li>Unlimited products, categories</li>
            <li>Use as complete storefront</li>
            <li>Integrates into any existing web</li>
            <li>Free add-ons for gateways, languages and real-time shipping</li>
            <li>Turn on shopping features as you need them</li>
            <li>Simple shops can be up and running in an hour. Just add your products. </li>
        </ul>
    </div>
		
    
        
</div> <!--End of id accordion -->