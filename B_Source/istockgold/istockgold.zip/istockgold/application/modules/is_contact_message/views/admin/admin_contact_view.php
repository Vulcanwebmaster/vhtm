<div id="main"><div id="page_title"><h1>View Message </h1></div>
<div id="status_box">
	<table width="99%" cellspacing="4" cellpadding="4" border="0">
	  <tbody>
		<tr>
			<td><strong>Message Id </strong>:</td>
			<td><?php echo $contact['message_id']?></td>
		</tr>
		<tr>
			<td><strong>Name </strong>:</td>
			<td><?php echo $contact['name']?></td>
		</tr>
		<tr>
			<td><strong>Company </strong>:</td>
			<td><?php echo $contact['company']?></td>
		</tr>
		<tr>
			<td><strong>Address </strong>:</td>
			<td><?php echo $contact['address']?></td>
		</tr>
		<tr>
			<td><strong>Phone </strong>:</td>
			<td><?php echo $contact['phone']?></td>
		</tr>
		<tr>
			<td><strong>Mobile </strong>:</td>
			<td><?php echo $contact['mobile']?></td>
		</tr>
		<tr>
			<td><strong>Email </strong>:</td>
			<td><?php echo $contact['email']?></td>
		</tr>
		<tr>
			<td><strong>Email Company </strong>:</td>
			<td><?php echo $contact['email_com']?></td>
		</tr>
		<tr>
			<td><strong>Content </strong>:</td>
			<td><?php echo $contact['contents']?></td>
		</tr>
  </tbody>
  </table>
</div>
</div>