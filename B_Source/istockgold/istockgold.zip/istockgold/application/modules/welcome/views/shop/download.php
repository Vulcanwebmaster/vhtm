<!-- Author: tienlx -->
<div id="main-column">
<div id="au-title">
	<label>Download</label>
</div>
<?php 
if (count($download))
foreach ($download as $key => $list)
	echo $list['content'];
?>
</div>
