
$(document).ready(function() {
	/*----------------------------------------------------------------------*/
	/* Navigation Stuff
	/*----------------------------------------------------------------------*/
	//Top Pageoptions
	$('#wl_config').click(function(){
		var $pageoptions = $('#pageoptions');
		if($pageoptions.height() < 200){
			$pageoptions.animate({'height':200});
			$(this).addClass('active');
		}else{
			$pageoptions.animate({'height':20});
			$(this).removeClass('active');
		}
		return false;
	});
	
	
	//Header navigation for smaller screens
	var $headernav = $('ul#headernav');
	
	$headernav.bind('click',function(){
		//if(window.innerWidth > 800) return false;
		var ul = $headernav.find('ul').eq(0);
		(ul.is(':hidden')) ? ul.addClass('shown') : ul.removeClass('shown');
	});
	
	$headernav.find('ul > li').bind('click',function(event){
		event.stopPropagation();
		var children = $(this).children('ul');
		
		if(children.length){
			(children.is(':hidden')) ? children.addClass('shown') : children.removeClass('shown');
			return false;
		}
	});
	
	//Search Field Stuff		
	var $searchform = $('#searchform'),
		$searchfield = $('#search');
	
	$searchfield
		.bind('focus.wl',function(){
	   		$searchfield.parent().animate({width: '150px'},100).select();
		})
		.bind('blur.wl',function(){
   			$searchfield.parent().animate({width: '90px'},100);
		});
		
	$searchform
		.bind('submit.wl',function(){
			//do something on submit				
			var query = $searchfield.val();
		});
		
	
	//Main Navigation		
	var $nav = $('#nav');
		
	$nav.delegate('li','click.wl', function(event){
		var _this = $(this),
			_parent = _this.parent(),
			a = _parent.find('a');
		_parent.find('ul').slideUp('fast');
		a.removeClass('active');
		_this.find('ul:hidden').slideDown('fast');
		_this.find('a').eq(0).addClass('active');
		event.stopPropagation();
	});
});	