<?php echo $this->doctype() ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   	<?php echo $this->headTitle() ?>
   	
   	<?php echo $this->headMeta() ?>
	<!-- Apple iOS and Android stuff -->
	<meta name="apple-mobile-web-app-capable" content="no">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<link rel="apple-touch-icon-precomposed" href="apple-touch-icon-precomposed.png">
	<!-- Apple iOS and Android stuff - don't remove! -->
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,maximum-scale=1">
	
	<?php echo $this->headLink()?>
	
	<!-- jQuery and jQuery UI -->
	<script type="text/javascript" src="<?php echo $this->baseUrl('/js/jquery-1.8.2.min.js');?>"></script>
	<script type="text/javascript" src="<?php echo $this->baseUrl('/js/jquery-ui.min.js');?>"></script>
	<?php echo $this->headScript()?>
</head>