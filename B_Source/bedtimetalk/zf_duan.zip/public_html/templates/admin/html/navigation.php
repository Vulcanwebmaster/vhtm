<nav>
	<ul id="nav">
		<li class="i_house"><a href="dashboard.html"><span>Dashboard</span></a></li>
		<li class="i_book"><a><span>Documentation</span></a>
			<ul>
				<li><a href="doc-alert.html"><span>Alert Boxes</span></a></li>
				<li><a href="doc-breadcrumb.html"><span>Breadcrumb</span></a></li>
				<li><a href="doc-calendar.html"><span>Calendar</span></a></li>
				<li><a href="doc-charts.html"><span>Charts</span></a></li>
				<li><a href="doc-dialog.html"><span>Dialog</span></a></li>
				<li><a href="doc-editor.html"><span>Editor</span></a></li>
				<li><a href="doc-file.html"><span>File</span></a></li>
				<li><a href="doc-fileexplorer.html"><span>Fileexplorer</span></a></li>
				<li><a href="doc-form.html"><span>Form</span></a></li>
				<li><a href="doc-gallery.html"><span>Gallery</span></a></li>
				<li><a href="doc-inputfields.html"><span>Inputfields</span></a></li>
				<li><a href="doc-slider.html"><span>Slider</span></a></li>
				<li><a href="doc-store.html"><span>Store</span></a></li>
				<li><a href="doc-widget.html"><span>Widget</span></a></li>
			</ul>
		</li>
		<li class="i_create_write"><a href="form.html"><span>Form</span></a></li>
		<li class="i_graph"><a href="charts.html"><span>Charts</span></a></li>
		<li class="i_images"><a href="gallery.html"><span>Gallery</span></a></li>
		<li class="i_blocks_images"><a href="widgets.html"><span>Widgets</span></a></li>
		<li class="i_breadcrumb"><a href="breadcrumb.html"><span>Breadcrumb</span></a></li>
		<li class="i_file_cabinet"><a href="fileexplorer.html"><span>Fileexplorer</span></a></li>
		<li class="i_calendar_day"><a href="calendar.html"><span>Calendar</span></a></li>
		<li class="i_speech_bubbles_2"><a href="dialogs_and_buttons.html"><span>Dialogs &amp; Buttons</span></a></li>
		<li class="i_table"><a href="datatable.html"><span>Table</span></a></li>
		<li class="i_typo"><a href="typo.html"><span>Typo</span></a></li>
		<li class="i_grid"><a href="grid.html"><span>Grid</span></a></li>
	</ul>
</nav>