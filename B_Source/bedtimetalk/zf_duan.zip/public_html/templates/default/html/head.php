<?php echo $this->doctype() ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   	<?php echo $this->headTitle() ?>
   	
   	<?php echo $this->headMeta() ?>
	
	<?php echo $this->headLink()?>
	
	<!-- jQuery and jQuery UI -->
	<script type="text/javascript" src="<?php echo $this->baseUrl('/js/jquery-1.8.2.min.js');?>"></script>
	<script type="text/javascript" src="<?php echo $this->baseUrl('/js/jquery-ui.min.js');?>"></script>
	<?php echo $this->headScript()?>
</head>