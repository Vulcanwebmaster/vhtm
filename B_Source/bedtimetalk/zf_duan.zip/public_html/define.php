<?php
//Duong dan den thu muc chua ung dung
defined('WEBROOT')
	|| define('WEBROOT', 
			  realpath(dirname(dirname(__FILE__))));
defined('APPLICATION_PATH')
	|| define('APPLICATION_PATH', 
			  WEBROOT . '/application');

// Define application environment
defined('APPLICATION_ENV')
    || define('APPLICATION_ENV',
              (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV')
                                         : 'developer'));
//Nap duong dan den cac thu vien se su dung trong ung dung
set_include_path(implode(PATH_SEPARATOR, array(
    WEBROOT . '/library',
    get_include_path(),
)));
//------------KHAI BAO DUONG DAN THUC DEN CAC THU MUC --------------
//Duong dan den thu muc /public
define('PUBLIC_PATH', WEBROOT . '/public_html');
define('TEMP_PATH', PUBLIC_PATH . '/tmp');
define('FILES_PATH', PUBLIC_PATH . '/files');
define('SCRIPTS_PATH',PUBLIC_PATH . '/js');
define('CAPTCHA_PATH',PUBLIC_PATH . '/captcha');
define('BLOCK_PATH',APPLICATION_PATH . '/blocks');
define('CONFIG_PATH',APPLICATION_PATH . '/configs');
define('CACHE_PATH',APPLICATION_PATH . '/caches');

//Duong dan den thu muc /templates
define('TEMPLATE_PATH', PUBLIC_PATH . '/templates');

//------------KHAI BAO DUONG DAN URL DEN CAC THU MUC --------------

//Duong dan goc 
define('BASE_URL','');
//Duong dan den thu muc /scripts
define('SRCIPTS_URL', BASE_URL . '/scripts');
//Duong dan den thu muc /templates
define('TEMPLATE_URL', '/templates');
//Duong dan den thu muc /captcha
define('CAPTCHA_URL', BASE_URL . '/captcha');
//Duong dan den thu muc /files
define('FILES_URL', BASE_URL . '/files');
//Duong dan den thu muc /images
define('IMAGES_URL', BASE_URL . '/images');