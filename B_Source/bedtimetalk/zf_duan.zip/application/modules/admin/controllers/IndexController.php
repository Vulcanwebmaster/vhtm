<?php
/**
 * Admin Module - Index Controller
 *
 * application/modules/admin/IndexController.php
 *
 * LICENSE:
 *
 * @copyright  2012 NIW Company
 * @license    [url]http://www.zend.com/license/3_0.txt[/url]   PHP License 3.0
 * @version    $Id...$
 * @link       [url][/url]
 * @since      File available since Release 1.x
 */  

 
 /**
 * Class IndexController 
 *
 * Controller mac dinh khi bat dau vao trang back-end
 *
 * @uses       Zendvn_Controller_Action
 * @copyright  2012 NIW Company
 * @license    [url]http://www.zend.com/license/3_0.txt[/url]   PHP License 3.0
 */  
 
class Admin_IndexController extends Zendvn_Controller_Action
{
	
	/**
	 * Khoi tao cac gia tri ban dau
	 * 
	 */
	public function init()
	{
		parent::init();
		
		//Thiet lap template cho Index Controller
		$template_path = TEMPLATE_PATH . "/admin/";
		$this->loadTemplate($template_path,'template.ini','template');
	}
	
	/**
	 * Index Action
	 * 
	 */
	public function indexAction()
	{
		echo "<h1>Admin Module - Index Controller - Index Action</h1>";
	}
		
}	