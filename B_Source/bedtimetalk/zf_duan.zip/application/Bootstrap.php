<?php
class Bootstrap extends Zend_Application_Bootstrap_Bootstrap 
{	
	/**
	 * Autoload
	 */
    protected function _initAutoload()
    {
        $front = Zend_Controller_Front::getInstance();
        $front->registerPlugin(new Zend_Controller_Plugin_ErrorHandler(array(
                                'module'     => 'error',
                                'controller' => 'index',
                                'action'     => 'index')));
		$front->addModuleDirectory(APPLICATION_PATH . '/modules');
		$front->setDefaultModule('default');	   	
        $autoloader = new Zend_Application_Module_Autoloader(array( 
                    	'namespace' => '', 
                    	'basePath' => dirname(__FILE__), )); 
        return $autoloader; 
    } 
	
	/**
	 * Start Session 
	 */ 
	protected function _initSession()
	{
		Zend_Session::start();
	}
	
	/**
	 * Define locate 
	 */ 
	protected function _initLocale()
	{
		$locale = new Zend_Locale('vi_VN');
		Zend_Registry::set('Zend_Locale',$locale);	
	}
	
	
	/**
	 * Define database config options 
	 */ 
	protected function _initDb()
	{	
		$optionResources = $this->getOption('resources');
		$dbOption = $optionResources['db'];
		
		$adapter = $dbOption['adapter'];
		$config = $dbOption['params'];
		
		$db = Zend_Db::factory($adapter,$config);
		$db->setFetchMode(Zend_Db::FETCH_ASSOC);
		$db->query("SET NAMES 'utf8'");
		$db->query("SET CHARACTER SET 'utf8'");
		
		Zend_Registry::set('connectDB',$db);
		
		Zend_Db_Table::setDefaultAdapter($db);
		
		return $db;
		
	}
	
	/**
	 * Khoi tao database
	 */
    protected function _initDatabase()
    {
        $db = $this->getPluginResource('db')->getDbAdapter();
        Zend_Registry::set('db', $db);    
    }

	/*
	 * Router for rewriting url
	 */
	/*===================================
	// Don't use in admin back-end
	protected function _initLoadRouter()
	{
		
		$config = new Zend_Config_Ini(CONFIG_PATH . '/app-router.ini','setup-router');
		$objRouter = new Zend_Controller_Router_Rewrite();
		//new Zend_Controller_Router_Route_Regex()
		$router = $objRouter->addConfig($config,'routers');
		
		$front = Zend_Controller_Front::getInstance();
		$front->setRouter($router);
	}
	//===================================
	 */
	
}











