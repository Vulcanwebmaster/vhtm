<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sample page</title>
</head>
<body>

<div id="container">
	<h1>This is sample page</h1>
</div>

</body>
</html>