<footer>
	<hr />
	<p><strong>Copyright &copy; 2011 NIW Admin</strong></p>
	<p>Theme by <a href="http://www.niw.com.vn">NIW</a></p>
</footer>