<h3>Home</h3>
	<ul class="toggle">
		<li class="icn_photo"><a href="#">Images Slider</a></li>
		<li class="icn_edit_article"><a href="#">Article</a></li>
		<li class="icn_categories"><a href="#">Categories</a></li>
	</ul>
<h3>Pages</h3>
	<ul class="toggle">
		<li class="icn_application"><a href="<?php echo base_url()?>example/admin">Example</a></li>
		<li class="icn_application"><a href="#">Manage Page 2</a></li>
		<li class="icn_application"><a href="#">Manage Page 3</a></li>
		<li class="icn_application"><a href="#">Manage Page 4</a></li>
		<li class="icn_application"><a href="#">Manage Page 5</a></li>
	</ul>
<h3>Users</h3>
	<ul class="toggle">
		<li class="icn_view_users"><a href="<?php echo base_url()?>auth/admin/members/">Manage Users</a></li>
	</ul>
<h3>Media</h3>
	<ul class="toggle">
		<li class="icn_folder"><a href="<?php echo base_url()?>filemanager/admin">File Manager</a></li>
	</ul>
<h3>System</h3>
	<ul class="toggle">
		<!-- <li class="icn_settings"><a href="#">System Info</a></li> -->
		<!-- <li class="icn_security"><a href="#">Security</a></li> -->
		<li class="icn_jump_back"><a href="<?php echo base_url()?>auth/logout">Logout</a></li>
	</ul>
