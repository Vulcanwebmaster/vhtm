<head>
	<title><?php echo $title?></title>
</head>
<body>
	<?php $this->load->view('front/header');?>
	<?php $this->load->view('front/content')?>
	<?php $this->load->view('front/footer');?>
</body>