<?php die(); ?>
gc start at 24/Jul/2012 10:26:28
