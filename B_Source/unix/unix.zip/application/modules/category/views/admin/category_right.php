<h2>Product Categories Notes</h2>
    <p>in module</p>
<div class="basic" id="accordion">
    <a>Categories</a>
    <div>
        <h3>Gallery</h3>
	<p>Add your notes here. This will be in jquery UI accordion.This is just an example. 
	... Don't change the following categories under <b>Gallery</b> </p>
        
            <h4>Gallery 1</h4>
            <h4>Gallery 2</h4>
            <h4>Front top</h4>
            <h4>Front bottom</h4>
            <h4>Gallery Web design</h4>            
    </div>
		
	<a>More info</a>
    <div>
	<h3>Some info</h3>
            <p>info info </p>
            <h3>Gallery 12</h3>
           <p>Go to Products and add images for web page Gallery 2</p>
           <h3>Front top</h3>
           <p>Go to Products and add images for web page Front top</p>
           <h3>Front bottom</h3>
           <p>Go to Products and add images for web page Front bottom</p>
           <h3>Gallery Webdesign</h3>
           <p>Go to Products and add images for web page Gallery Web design</p>
    </div>
    	
    <a>Products</a>
    <div>
	<h3>Gallery 1</h3>
            <p>Go to Products and add images for web page Gallery 1</p>
            <h3>Gallery 2</h3>
           <p>Go to Products and add images for web page Gallery 2</p>
           <h3>Front top</h3>
           <p>Go to Products and add images for web page Front top</p>
           <h3>Front bottom</h3>
           <p>Go to Products and add images for web page Front bottom</p>
           <h3>Gallery Webdesign</h3>
           <p>Go to Products and add images for web page Gallery Web design</p>
    </div>

        
</div> <!--End of id accordion -->