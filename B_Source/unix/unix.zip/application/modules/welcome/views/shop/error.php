<?php print displayStatus();?>
<?php
/*
if ($this->session->flashdata('subscribe_msg')){
	echo "<div class='status_box'>";
	echo $this->session->flashdata('subscribe_msg');
	echo "</div>";
}
 * 
 */
?>

<?php echo $title; ?>

