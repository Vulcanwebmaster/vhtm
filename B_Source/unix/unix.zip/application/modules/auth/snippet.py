<div id="content">
    <a name="top"></a>
            <h2></h2>

<div class="buttons">
	<a href="http://localhost/unix/index.php/hoithao/admin/create">
    <img src="http://localhost/unix/assets/icons/add.png" alt="add">    T?o h?i th?o m?i    </a>
</div>
