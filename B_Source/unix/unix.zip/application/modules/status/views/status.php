<div class="status_box <?php print $type; ?>">
    <h6><?php print $this->lang->line('status_type_' . $type);?></h6>
    <?php print ul($messages); ?>
</div>
