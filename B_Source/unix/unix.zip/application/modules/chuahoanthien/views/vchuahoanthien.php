<div style="width:1000px; margin:auto; text-align:center">
	<img alt="" src="<?php echo base_url();?>assets/unix/images/repairing.jpg"/>
	<h1>Website đang được hoàn thiện</h1>
</div>