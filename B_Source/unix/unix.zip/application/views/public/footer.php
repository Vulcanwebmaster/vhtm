    <div id="footer">
        <a href="#top"><?php print $this->lang->line('general_top')?></a><br />
        This site is powered by <a href="http://www.niw.com.vn">NIW </a><br />
        &copy; Copyright 2012 - <a href="http://www.niw.com.vn">NIW</a> -  All rights Reserved
    </div> 
</div>
<?php print $this->bep_assets->get_footer_assets();?>
</body>
</html>