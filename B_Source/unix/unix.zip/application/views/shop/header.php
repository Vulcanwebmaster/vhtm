<div id="header">
	<style type="text/css">
		.nivo-controlNav{display:none}
	</style>
	<div id="top-bar"></div>
	<div id="header-main">
		<div id="head-content">
			<a href="<?php echo base_url();?>"><img id="logo" src="<?php echo base_url();?>assets/unix/images/logo.png"/></a>
			<div style="float:right; width:83%">
				<div style="height:30px"></div>
				<ul id="nav">
					<li class="menuitem-head"><a></a></li>
					<li class="menuitem"><a href="<?php echo base_url();?>index.php"><img src="<?php echo base_url();?>assets/unix/images/trang chu.png" alt=""/>Trang chủ</a></li>
					<li class="menuitem"><a href="<?php echo base_url();?>index.php/gioithieu"><img src="<?php echo base_url();?>assets/unix/images/gioi thieu.png" alt=""/>Giới thiệu</a></li>
					<li class="menuitem"><a href="<?php echo base_url();?>index.php/hoithao"><img src="<?php echo base_url();?>assets/unix/images/hoi thao.png" alt=""/>Hội thảo</a></li>
					<li class="menuitem"><a href="<?php echo base_url();?>index.php/khoahoc"><img src="<?php echo base_url();?>assets/unix/images/khoa hoc.png" alt=""/>Khóa học</a></li>
					<li class="menuitem"><a href="<?php echo base_url();?>index.php/thuvien"><img src="<?php echo base_url();?>assets/unix/images/thu vien.png" alt=""/>Thư viện</a></li>
					<li class="menuitem">
						<a id="abc" href="<?php echo base_url();?>index.php/tintuc"><img src="<?php echo base_url();?>assets/unix/images/news-icon.png" alt=""/>Sự kiện</a>
						<div style="background-color: #E3E3E7;color:white" id="xyz">
                                    <a href="<?php echo base_url();?>index.php/tintuc">Tin tức</a><hr />
                                    <a href="<?php echo base_url();?>index.php/hoidap">Hỏi đáp</a><hr />
                                    <a href="<?php echo base_url();?>index.php/diemthi">Xem điểm thi</a>
                        </div> 
					</li>
					<li class="menuitem"><a href="<?php echo base_url();?>index.php/camnhan"><img src="<?php echo base_url();?>assets/unix/images/cam nhan.png" alt=""/>Cảm nhận</a></li>
					<li class="menuitem"><a href="<?php echo base_url();?>index.php/lienhe"><img src="<?php echo base_url();?>assets/unix/images/lien he.png" alt=""/>Góp ý</a></li>

					<li class="menuitem-foot"><a></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>