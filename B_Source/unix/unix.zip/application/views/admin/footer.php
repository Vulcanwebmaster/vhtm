    <div id="footer">
        <div id="copyright">
            <a href="niw.com.vn">NIW</a> &copy; Copyright 2011-  All rights Reserved
        </div>
    </div>
</div>
<?php print $this->bep_assets->get_footer_assets();?>
</body>
</html>