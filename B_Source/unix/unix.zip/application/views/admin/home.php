<h2><?php print $header?></h2>

<?php print $dashboard; ?>