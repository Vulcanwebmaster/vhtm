<?php
$tags["amazon"] = "{title}, {keyword}, {url}, {link}, {description}, {features}, {thumbnail}, {buynow-big}, {buynow-ger}, {buynow}, {listprice}, {price}, {price-updating}, {reviews-iframe}, {reviews-noiframe}, {smallimage}, {mediumimage}, {largeimage}";
$tags["article"] = "{title}, {keyword}, {url}, {article}, {authortext}";
$tags["clickbank"] = "{title}, {keyword}, {url}, {link}, {description}";
$tags["ebay"] = "{title}, {keyword}, {url}, {thumbnail}, {price}, {descriptiontable}, {description}";
$tags["flickr"] = "{title}, {keyword}, {url}, {image}, {date}, {owner}, {description}";
$tags["rss"] = "{title}, {keyword}, {url}, {content}, {source}, {author}, {mediacontent}, {mediathumbnail}, {enclosure}";
$tags["yahooanswers"] = "{title}, {keyword}, {url}, {question}, {user}, {answers}";
$tags["youtube"] = "{title}, {keyword}, {url}, {thumbnail}, {video}, {rating}, {description}";
$tags["yahoonews"] = "{title}, {keyword}, {url}, {thumbnail}, {summary}, {source}";
$tags["twitter"] = "{title}, {keyword}, {url}, {tweet}, {author}, {authorname}, {authorurl}, {date}";
$tags["shopzilla"] = "{title}, {keyword}, {url}, {description}, {thumbnail}, {manufacturer}, {offers}, {minprice}, {maxprice}";
$tags["oodle"] = "{title}, {keyword}, {url}, {content}, {thumbnail}, {city}, {address}, {latitude}, {longitude}, {price}, {condition}, {features}, {seller_type}, {delivery}";
$tags["pressrelease"] = "{title}, {keyword}, {url}, {thumbnail}, {summary}, {pressrelease}";
$tags["commissionjunction"] = "{title}, {keyword}, {url}, {description}, {thumbnail}, {price}, {currency}, {saleprice}, {listprice}, {advertiser}, {instock}, {imageurl}";
$tags["itunes"] = "{thumbnail}, {keyword}, {trackname}, {collectionname}, {artistname}, {artworkUrl30}, {artworkUrl60}, {artworkUrl100}, {collectionPrice}, {trackPrice}, {currency}, {genre}, {artisturl}, {collectionurl}, {trackurl}, {previewurl}";
$tags["eventful"] = "{title}, {keyword}, {url}, {description}, {begin}, {end}, {venuename}, {venueurl}, {venueaddress}, {city}, {country}";
$tags["linkshare"] = "{title}, {keyword}, {url}, {description}, {thumbnail}, {summary}, {category}, {price}, {imageurl}, {merchant}";
$tags["yelp"] = "{title}, {keyword}, {url}, {rating}, {thumbnail}, {address}, {city}, {reviewscount}, {reviews:x}";
$tags["shareasale"] = "{title}, {keyword}, {url}, {description}, {thumbnail}, {bigimage}, {merchant}, {category}, {manufacturer}, {isbn}, {status}, {price}, {listprice}, {custom1}, {custom2}, {custom3}";
$tags["avantlink"] = "{title}, {keyword}, {url}, {description}, {thumbnail}, {largeimage}, {mediumimage}, {merchant}, {price}, {listprice}, {brand}";
$tags["plr"] = "{title}, {keyword}, {article}";

?>

<div class="wrap">
<style type="text/css">
table.addt {padding:5px;margin-bottom:10px;background:#F5F5F5;border:1px dotted #F0F0F0;}
table.addt:hover {background:#F2F2F2;border:1px dotted #d9d9d9;}
div.expld {padding:5px;margin-bottom:10px;background:#fffff0;border:1px dotted #e5dd83;}
div.expld:hover {background:#ffffe5;border:1px dotted #e5db6c;} 
a.expll {display:block;padding:10px;}
a.aactive {background:#fff;}
a.expll:hover {display:block;padding:10px;background:#fff;}
h3 a,h2 a {font-size:80%;text-decoration:none;margin-left:10px;}
</style>
<h2>WP Robot Post Templates <a href="?page=wpr-templates&add=post"><?php _e("&rarr; Add New","wprobot") ?></a></h2>

	<?php 
	if ($records) {
		
		$type = "";
		$i = 1;
		?>
	<div style="width:70%;">	
		<form method="post" id="wpr_options">	

		<p>
		<input class="button-primary" type="submit" name="tsaveall" value="<?php _e("Save All Changes","wprobot") ?>" />
		</p>		
		
		<input size="5" name="tids" type="hidden" value="<?php echo implode(",", $tids); ?>"/>		
		
		<?php
        foreach ($records as $record) { 
		?>
			
			<a name="<?php echo $i;?>"></a>
			<table class="addt" width="100%">	
				<tr>
					<td valign="top" width="50%">
						<strong style="font-size:120%;border-bottom:1px dotted #ccc;"><?php _e("Post Template Preset","wprobot") ?> <?php echo $i;?></strong><br/>
						<?php _e("Name:","wprobot") ?> <input class="input" name="tname<?php echo $record->id; ?>" type="text" value="<?php echo $record->name; ?>"/>						
					</td>
					<td>
						<strong><?php _e("Post Title","wprobot") ?></strong><br/>
						<textarea name="ttitle<?php echo $record->id; ?>" rows="2" cols="30"><?php echo $record->title;?></textarea>
					</td>
				</tr>				
				<tr>
					<td width="50%">
					</td>
					<td rowspan="3">
						<strong><?php _e("Post Content","wprobot") ?></strong><br/>
						<textarea name="tcontent<?php echo $record->id; ?>" rows="5" cols="30"><?php echo $record->content;?></textarea>
					</td>
				</tr>
				<tr>
					<td>
						<input class="button" type="submit" name="tsave<?php echo $record->id; ?>" value="<?php _e("Save Changes","wprobot") ?>" /> 
						<input class="button" type="submit" name="tcopy<?php echo $record->id; ?>" value="<?php _e("Copy","wprobot") ?>" />						
						<input class="button" type="submit" name="tdelete<?php echo $record->id; ?>" value="<?php _e("Delete","wprobot") ?>" />
					</td>
				</tr>
				<tr>
					<td>
					</td>
				</tr>			
			</table>

			<?php if($type != $record->type) { $type = $record->type; } $i++; ?>			
			
		<?php } ?>
	</form>
	
	<?php } ?>		
</div>
</div>