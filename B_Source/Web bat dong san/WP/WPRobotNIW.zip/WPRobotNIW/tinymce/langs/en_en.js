tinyMCE.addI18n({en_US:{
wprobot:{	
desc : 'Insert WP Robot Content'
}}});