Steps to set up the environment:
1) Download latetst version of CodeIgniter framework and install it.
2) Copy files from directory *Code*  to the same paths inside CodeIgniter directory, for example:
 files mojmojster_database.php and mojmojster_session.php and others -> inside / of CodeIgniter directory
 directories cssmodules, jsframework, jsmodules -> inside / of CodeIgniter directory
 contents of /application/ subdirectories -> inside the same /application/ subdirectories of CodeIgniter
3) load database dump into database "mojmojster" from *Database* directory into your MySQL server
4) set configuration in /application/config/database.php according to your MySQL server accounts settings  ($db['default'])
5) set /savedfiles directory permissions in a way that PHP can read and write in it
6) set constants in the beginning of /showfile.php according to your MySQL server accounts settings.
7) set $config['base_url'] in file /application/config/config.php to URL on your developement server.

The environment is prepared.

Before you proceed with work, you should check *Documentation*/developement_guidelines.pdf for guidelines on how to structure your files and write code, and *Docuementation*/framework_reference.pdf on how to use the provided code.