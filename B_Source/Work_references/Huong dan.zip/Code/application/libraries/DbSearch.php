<?php
// (c) 2012 HeyYa dev team. All rights reserved.

class dbSearch {
	function returnCraftsmenSearchList($searchParameters = false) // �e so parametri (boolean)false, vrne default (privzete).
	{
		//TODO: define search parameters 
		
	}
	
	function returnCraftsmenSearchBoxes($searchParameters = false) // �e so parametri (boolean)false, vrne default (privzete).
	{
		//TODO: define search parameters
	}
}
?>