<?php
// (c) 2012 HeyYa dev team. All rights reserved.

$CI =& get_instance();
$CI->load->library('SessionContext');

$Context = new SessionContext();

?>