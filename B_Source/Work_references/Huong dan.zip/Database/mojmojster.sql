-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Gostitelj: localhost
-- Čas nastanka: 12 Sep 2012 ob 12:35 PM
-- Različica strežnika: 5.1.33
-- Različica PHP: 5.2.9-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Podatkovna baza: `mojmojster`
--

-- --------------------------------------------------------

--
-- Struktura tabele `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Odloži podatke za tabelo `categories`
--

INSERT INTO `categories` (`id`, `category`) VALUES
(1, 'Dimnikarstvo'),
(2, 'Brusilstvo'),
(3, 'Gozdarstvo'),
(4, 'Ključavničarstvo'),
(5, 'Manjša hišna popravila in montažerstvo'),
(6, 'Obdelava površin'),
(7, 'Prodaja'),
(8, 'Projektiranje'),
(9, 'Restavratorstvo'),
(10, 'Transport in gradbena mehanizacija'),
(11, 'Varovanje');

-- --------------------------------------------------------

--
-- Struktura tabele `craftsmen`
--

CREATE TABLE IF NOT EXISTS `craftsmen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profileviews` int(11) NOT NULL,
  `last_visit` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `work_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `vision` text COLLATE utf8_unicode_ci NOT NULL,
  `more_about` text COLLATE utf8_unicode_ci NOT NULL,
  `basic_about` text COLLATE utf8_unicode_ci NOT NULL,
  `map_location` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `web_pages` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `bg_file_id` int(11) NOT NULL,
  `logo_file_id` int(11) NOT NULL,
  `certificates` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=254 ;

--
-- Odloži podatke za tabelo `craftsmen`
--


-- --------------------------------------------------------

--
-- Struktura tabele `craftsmencategories`
--

CREATE TABLE IF NOT EXISTS `craftsmencategories` (
  `craftsman_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Odloži podatke za tabelo `craftsmencategories`
--


-- --------------------------------------------------------

--
-- Struktura tabele `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `craftsman_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=247 ;

--
-- Odloži podatke za tabelo `employees`
--


-- --------------------------------------------------------

--
-- Struktura tabele `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filetype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Odloži podatke za tabelo `files`
--


-- --------------------------------------------------------

--
-- Struktura tabele `inquiries`
--

CREATE TABLE IF NOT EXISTS `inquiries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` bigint(20) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name_surname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `region` int(11) NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `mail` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `what` text COLLATE utf8_unicode_ci NOT NULL,
  `deadline_start` bigint(20) NOT NULL,
  `deadline_finish` bigint(20) NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=148 ;

--
-- Odloži podatke za tabelo `inquiries`
--


-- --------------------------------------------------------

--
-- Struktura tabele `inquiriesfiles`
--

CREATE TABLE IF NOT EXISTS `inquiriesfiles` (
  `inquiry_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Odloži podatke za tabelo `inquiriesfiles`
--


-- --------------------------------------------------------

--
-- Struktura tabele `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `craftsman_id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=158 ;

--
-- Odloži podatke za tabelo `news`
--


-- --------------------------------------------------------

--
-- Struktura tabele `portalcomments`
--

CREATE TABLE IF NOT EXISTS `portalcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=172 ;

--
-- Odloži podatke za tabelo `portalcomments`
--


-- --------------------------------------------------------

--
-- Struktura tabele `productcategories`
--

CREATE TABLE IF NOT EXISTS `productcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `craftsman_id` int(11) NOT NULL,
  `category_title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=190 ;

--
-- Odloži podatke za tabelo `productcategories`
--


-- --------------------------------------------------------

--
-- Struktura tabele `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_timestamp` bigint(20) NOT NULL,
  `answer_timestamp` bigint(20) NOT NULL,
  `craftsman_id` int(11) NOT NULL,
  `asking` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `answering_id` int(11) NOT NULL,
  `question` text COLLATE utf8_unicode_ci NOT NULL,
  `answer` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=229 ;

--
-- Odloži podatke za tabelo `questions`
--


-- --------------------------------------------------------

--
-- Struktura tabele `ratings`
--

CREATE TABLE IF NOT EXISTS `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `rating` int(11) NOT NULL,
  `rated_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=568 ;

--
-- Odloži podatke za tabelo `ratings`
--


-- --------------------------------------------------------

--
-- Struktura tabele `references`
--

CREATE TABLE IF NOT EXISTS `references` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` bigint(20) NOT NULL,
  `file_id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_author` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `craftsman_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=235 ;

--
-- Odloži podatke za tabelo `references`
--


-- --------------------------------------------------------

--
-- Struktura tabele `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `entity_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Odloži podatke za tabelo `reports`
--


-- --------------------------------------------------------

--
-- Struktura tabele `sentinquiries`
--

CREATE TABLE IF NOT EXISTS `sentinquiries` (
  `inquiry_id` int(11) NOT NULL,
  `craftsman_id` int(11) NOT NULL,
  `checked` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Odloži podatke za tabelo `sentinquiries`
--


-- --------------------------------------------------------

--
-- Struktura tabele `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `connected_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Odloži podatke za tabelo `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `type`, `connected_id`) VALUES
(1, 'username', 'password', 'craftsman', 1);
