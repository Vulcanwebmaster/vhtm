<pre>Array
(
    [currentFolderPath] => ../../../../assets/images/
    [new_folder] => Licensing
)
</pre>

19/Dec/2011 04:13:13