<header>
    <div>
        <h1><a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>assets/webbanhang/images/logo.gif" alt=""></a></h1>
        <div class="social-icons">
        	<span style="font-size:20px; color:#abaaaa">Đề xuất:</span>
            <a href="#" class="icon-3"></a>
            <a href="#" class="icon-2"></a>
            <a href="#" class="icon-1"></a>
        </div>
        <div id="slide">		
            <div class="slider">
                <ul class="items">
                    <li><img src="<?php echo base_url();?>assets/webbanhang/images/slider-1.jpg" alt="" /></li>
                    <li><img src="<?php echo base_url();?>assets/webbanhang/images/slider-2.jpg" alt="" /></li>
                    <li><img src="<?php echo base_url();?>assets/webbanhang/images/slider-3.jpg" alt="" /></li>
                </ul>
            </div>	
            <a href="#" class="prev"></a><a href="#" class="next"></a>
        </div>
        <nav>
            <ul class="menu">
                <li id="trangchu"><a href="<?php echo base_url();?>">Trang chủ</a></li>
                <li id="tinhnang"><a href="<?php echo base_url();?>tinhnang">Tính năng</a></li>
                <li id="khogiaodien"><a href="<?php echo base_url();?>khogiaodien">Kho giao diện</a></li>
                <li id="dichvu"><a href="<?php echo base_url();?>dichvu">Dịch vụ</a></li>
                <li id="lienhe"><a href="<?php echo base_url();?>lienhe">Liên hệ</a></li>
            </ul>
        </nav>
    </div>
</header>