<footer>
	<ul id="bottom-menu">
		<li><a href="<?php echo base_url();?>">Trang chủ</a></li>
		<li>|</li>
		<li><a href="<?php echo base_url();?>tinhnang">Tính năng</a></li>
		<li>|</li>
		<li><a href="<?php echo base_url();?>khogiaodien">Kho giao diện</a></li>
		<li>|</li>
		<li><a href="<?php echo base_url();?>dichvu">Dịch vụ</a></li>
		<li>|</li>
		<li><a href="<?php echo base_url();?>lienhe">Liên hệ</a></li>
		<li>
			<p>Copyright &copy; 2012 by <a href="http://www.niw.com.vn">NIW</a></p>
		</li>
	</ul>
</footer>
