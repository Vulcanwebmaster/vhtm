<div class="grid_4">
        <div class="left-1">
            <h2 class="top-1 p3">Tư vấn</h2>
            <div id="contact-panel">
            	<a class="contact-online" href="ymsgr:sendim?kisianhtrang_110205">
            		<div>
            			Nguyễn Tiến Mạnh
            			<img alt="" src="http://opi.yahoo.com/online?u=kisianhtrang_110205&amp;m=g&amp;t=2&amp;l=us"/>
            			<h4>01692253134</h4>
            		</div>
            	</a>
            	<hr/>
            	<a class="contact-online" href="ymsgr:sendim?bonghongxanh_9x">
            		<div>
            			Nguyễn Loan
            			<img alt="" src="http://opi.yahoo.com/online?u=bonghongxanh_9x&amp;m=g&amp;t=2&amp;l=us"/>
            			<h4>01689962845</h4>
            		</div>
            	</a>
            </div>
            <!-- img src="<?php echo base_url();?>assets/webbanhang/images/page1-img4.png" alt="" -->
            <iframe width="270" height="200" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps/ms?msa=0&amp;msid=216745339241060542234.0004c4102909de9d3e735&amp;ie=UTF8&amp;t=m&amp;ll=21.006317,105.78186&amp;spn=0.064101,0.09304&amp;z=12&amp;output=embed"></iframe><br /><small style="font-size:11px">View <a href="https://maps.google.com/maps/ms?msa=0&amp;msid=216745339241060542234.0004c4102909de9d3e735&amp;ie=UTF8&amp;t=m&amp;ll=21.006317,105.78186&amp;spn=0.064101,0.09304&amp;z=12&amp;source=embed" style="color:#0000FF;text-align:left">Công ty TNHH NIW</a> in a larger map</small>
        </div>
      </div>