<p>
	Chương trình liên kết cùng NIW Shopping Cart mang đến cho bạn một cơ hội tuyệt vời để tăng thêm thu nhập. 
	Chỉ cần một vài thao tác đơn giản đăng ký tham gia và giới thiệu khách hàng cho NIW Shopping Cart là bạn đã nhận được những lợi ích rất lớn từ NIW Shopping Cart mang lại
</p>

<h3>Lợi ích được hưởng khi tham gia liên kết cùng NIW Shopping Cart</h3>
<ul>
	<li>Hưởng trực tiếp 15 - 20%/ giá trị mỗi hợp đồng mà bạn giới thiệu</li>
	<li>Được sử dụng miễn phí công cụ theo dõi thống kê kết quả công việc rất trung thực và chính xác</li>
	<li>Được sử dụng miễn phí các tài liệu hướng dẫn sử dụng, tài liệu hướng dẫn kinh doanh (bản mềm, video)</li>
	<li>Hướng tất cả chương trình khuyến mại, chính sách thúc đẩy kinh doanh NIW Shopping Cart phát hành</li>
	<li>Được sử dụng miễn phí công cụ theo dõi thống kê kết quả công việc rất trung thực và chính xác</li>
	<li>Không có bất kỳ rủi ro nào khi tham gia</li>
</ul>

<h3>Cơ chế hoạt động</h3>
<p><strong>Bước 1:</strong> Đăng ký tham gia liên kết cũng NIW Shopping Cart để được cấp 1 mã link riêng</p>
<p><strong>Bước 2:</strong> Sử dụng mã link riêng để giới thiệu NIW Shopping Cart với các khách hàng. 
	Với mỗi khách hàng đăng ký sử dụng dịch vụ qua mã link của thành viên nào sẽ được tính trực tiếp cho thành viên đó</p>
<p><strong>Bước 3:</strong> Hưởng trực tiếp lợi ích từ giá trị hợp đồng mà khách hàng ký với NIW Shopping Cart. 
	Thành viên vào công cụ thống kê để xem chi tiết số lượng khách hàng giới thiệu được cho NIW Shopping Cart và số lượng đã đăng ký sử dụng với NIW Shopping Cart để biết được tổng mức thu nhập của mình</p>
<p>Liên kết cùng NIW Shopping Cart rất nhanh chóng - đơn giản giúp bạn tăng cao thu nhập nhanh chóng</p>

<h3>Số tiền bạn nhận được từ chương trình liên kết</h3>
<ul>
	<li>Khi có 1 HĐ egold 1 năm trị giá 3.840.000 tối thiểu bạn sẽ nhận được 576.000 VNĐ</li>
	<li>Khi có 1 HĐ egold 2 năm trị giá 7.680.000 tối thiểu bạn sẽ nhận được 1.152.000 VNĐ</li>
	<li>Khi có 1 HĐ eplatinum 2 năm trị giá 11.760.000 tối thiểu bạn sẽ nhận được 1.764.000 VNĐ</li>
	<li>Khi có 1 HĐ ediamond 2 năm trị giá 15.600.000 tối thiểu bạn sẽ nhận được 2.340.000 VNĐ</li>
</ul>

<h3>Thanh toán</h3>
<ul>
	<li>Người liên kết chỉ được rút tiền khi có khách hàng thứ 2 giới thiệu ký hợp đồng chính thức với NIW Shopping Cart</li>
	<li>Trường hợp người liên kết chỉ giới thiệu được 1 khách hàng cho NIW Shopping Cart sẽ không đủ điều kiện để yêu cầu thanh toán</li>
</ul>