<?php
echo $reply;