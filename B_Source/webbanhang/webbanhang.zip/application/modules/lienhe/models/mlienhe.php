<?php
	class Mlienhe extends CI_Model
	{
		function index()
		{
			parent::__construct();
		}
	}
?>