<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| config for mailchimp2col-1-2-leftsidebar
|--------------------------------------------------------------------------
|
|
*/
$config['header_img'] = TRUE;
$config['img_one'] = TRUE;
$config['img_tow'] = TRUE;
$config['img_three'] = TRUE;
$config['msg_one'] = TRUE;
$config['msg_two'] = TRUE;
$config['msg_three'] = TRUE;
$config['header_short_msg'] = TRUE;
$config['email_link'] = TRUE;
$config['heading_one'] = TRUE;
$config['heading_two'] = TRUE;
$config['heading_three'] = TRUE;
$config['follow_twitter'] = TRUE;
$config['header_img'] = TRUE;
$config['header_img'] = TRUE;
$config['header_img'] = TRUE;


/* End of file config.php */
/* Location: ./applicaiton/modules/subscribers/views/templates//config.php */