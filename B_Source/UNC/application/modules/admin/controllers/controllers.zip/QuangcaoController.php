<?php
class Admin_QuangcaoController extends Zend_Controller_Action{
	
		protected $mquangcao;
		protected $role;
		
		function init()
		{
			$layoutPath = APPLICATION_PATH  . '/templates/admin';
		      $option = array ('layout' => 'index', 
		                   'layoutPath' => $layoutPath );
		      Zend_Layout::startMvc ( $option );
			  $this->mquangcao=new Admin_Model_Mquangcao();
			  @session_start();
			  if(isset($_SESSION['role']))
			  	$this->role = $_SESSION['role'];
			  else {
				  $this->_redirect($this->view->baseUrl().'/../admin');
			  }
			  if(isset($_SESSION['user_id']))
			 	 $this->user_id = $_SESSION['user_id'];
			  else {
				  $this->_redirect($this->view->baseUrl().'/../admin');
			  }
			  $_SESSION["backend_current_menu"]="menu-quanlyanh";
		}
		
		function setForm()
		{
			
			$form=new Zend_Form;
			$form->setMethod('post')->setAction('');
			
			$ads_banner = new Zend_Form_Element_Textarea('ads_banner');
			$ads_banner->setRequired(true)->addValidator('NotEmpty',true,array('messages'=>'Biểu ngữ không được để trống'));
			
			$ads_position = new Zend_Form_Element_Text('ads_position');
			$ads_position->setRequired(true)->addValidator('NotEmpty',true,array('messages'=>'Vị trí không được để trống'));
			
			$ads_name = new Zend_Form_Element_Text('ads_name');
			$ads_name->setRequired(true)->addValidator('NotEmpty',true,array('messages'=>'Tên quảng cáo không được để trống'));
			
			$ads_link = new Zend_Form_Element_Text('ads_link');
			$ads_link->setRequired(true)->addValidator('NotEmpty',true,array('messages'=>'Đường dẫn không được để trống'));
			
			$ads_position = $form->createElement("select","ads_position",array(
                                                        "label" => "Vị trí",
                                                   "multioptions"=> array(
                                                                      "1" => "Trên",
                                                                      "2" => "Giữa",
                                                                      "3" => "Trái",
																	  "4" => "Phải",
																	  "5" => "Nội dung")));
			$ads_banner->removeDecorator('HtmlTag')->removeDecorator('Label');
			$ads_position->removeDecorator('HtmlTag')->removeDecorator('Label');
			$ads_name->removeDecorator('HtmlTag')->removeDecorator('Label');
			$ads_link->removeDecorator('HtmlTag')->removeDecorator('Label');
			
			$form->addElements(array($ads_banner,$ads_position,$ads_name,$ads_link));
			return $form;
		}
		
		function indexAction()
		{
			$this->view->headTitle('UNC - Admin website');
			$this->view->headLink()->appendStylesheet($this->view->baseUrl().'/application/templates/admin/css/layout.css');
			$this->view->headScript()->appendFile($this->view->baseUrl().'/application/templates/admin/js/jquery-1.7.2.min.js','text/javascript');
			$this->view->headScript()->appendFile($this->view->baseUrl().'/application/templates/admin/js/hideshow.js','text/javascript');

			$listQuangcao = array();
			//echo $this->role;die();
			if($this->role =="0"| $this->role =="1"| $this->role =="2" )
			{
				$listQuangcao= $this->mquangcao->getListQC();
				//var_dump($listQuangcao);die();
				//Nếu là admin thì lấy ra danh sách tất cả các comment
				$paginator = Zend_Paginator::factory($listQuangcao);
				$paginator->setItemCountPerPage(25);        
        	$currentPage = $this->_request->getParam('page',1);
         	$paginator->setCurrentPageNumber($currentPage);
        	$this->view->list=$paginator;
			$this->view->role = $this->role;
			}
			
			$this->view->title="Quản lý mục quảng cáo";
		}
		
		function _getInput($form)
		{
			$input = array(
					'ads_banner' => $this->_request->getPost('ads_banner'),
					'ads_position' => $this->_request->getPost('ads_position'),
					'ads_name' => $this->_request->getPost('ads_name'),
					'ads_link' => $this->_request->getPost('ads_link'),
					'ads_start_date' => $this->_request->getPost('ads_start_date'),
					'ads_end_date' => $this->_request->getPost('ads_end_date'),
					'category_id' => $this->_request->getPost('category_id'),
			);
			return $input;
		}
		
		function addAction()
		{
			$this->view->headTitle('UNC - Admin website');
			$this->view->headLink()->appendStylesheet($this->view->baseUrl().'/application/templates/admin/css/layout.css');
			$this->view->headScript()->appendFile($this->view->baseUrl().'/application/templates/admin/js/jquery-1.7.2.min.js','text/javascript');
			$this->view->headScript()->appendFile($this->view->baseUrl().'/application/templates/admin/js/hideshow.js','text/javascript');

			$mquangcao = new Admin_Model_Mquangcao;
			$this->view->list = $mquangcao->getListQC();
			$this->view->listdm = $mquangcao->getListDM();
			$this->view->title="Thêm quảng cáo";
			$form = $this->setForm();
			
			if($this->_request->isPost())
			{
				if($form->isValid($_POST))
				{
					$input=$this->_getInput($form);
					if ($this->mquangcao->add($input))
					{
						$_SESSION['result']='Thêm mới thành công';
						$this->_redirect($this->view->baseUrl().'/../admin/quangcao');
					}
					else 
					{
						$_SESSION['result']='Thêm mới Thất bại';
						$this->_redirect($this->view->baseUrl().'/../admin/quangcao');
					}
				}
				else 
				{
					$form->populate($_POST);
				}
			}
			
			$this->view->form=$form;
		}

		function editAction()
		{
			$this->view->headTitle('UNC - Admin website');
			$this->view->headLink()->appendStylesheet($this->view->baseUrl().'/application/templates/admin/css/layout.css');
			$this->view->headScript()->appendFile($this->view->baseUrl().'/application/templates/admin/js/jquery-1.7.2.min.js','text/javascript');
			$this->view->headScript()->appendFile($this->view->baseUrl().'/application/templates/admin/js/hideshow.js','text/javascript');
			
			$mquangcao = new Admin_Model_Mquangcao;
			$form=$this->setForm();
			$this->view->listdm = $mquangcao->getListDM();
			$this->view->list = $mquangcao->getListQC();
			$this->view->query = $mquangcao->getOne($this->getRequest()->getParam('id'));
			$info = $mquangcao->getOne($this->getRequest()->getParam('id'));
			$this->view->title="Sửa thông tin quảng cáo";
			$form->getElement('ads_position')->setValue($info['ads_position']);
			//var_dump($mquangcao->getOne($this->getRequest()->getParam('id')));die();
			if($this->_request->isPost())
			{
				//$ret = preg_match('#<img.*/>#',$this->_request->getPost('ads_banner'),$match);
				$data = array(
					'ads_banner' => str_replace('\\','',$this->_request->getPost('ads_banner')),
					'ads_position' => $this->_request->getPost('ads_position'),
					'ads_name' => $this->_request->getPost('ads_name'),
					'ads_link' => $this->_request->getPost('ads_link'),
					'ads_start_date' => $this->_request->getPost('ads_start_date'),
					'ads_end_date' => $this->_request->getPost('ads_end_date'),
					'category_id' => $this->_request->getPost('category_id'),
				);
				
				
			//var_dump($match);die();
				$mquangcao->edit($this->getRequest()->getParam('id'),$data);
				$this->_redirect($this->view->baseUrl().'/../admin/quangcao');
			}
			$this->view->form=$form;
		}

		function delAction()
		{
			$mquangcao = new Admin_Model_Mquangcao;
			$mquangcao->del($this->getRequest()->getParam('id'));
			if($this->role == "0")
			{
				if ($this->mquangcao->del($id))
				$_SESSION['result']='Xóa thành công';
				else $_SESSION['result']='Xóa không thành công';
			}
			else 
			{
				$_SESSION['result']='Bạn không có quyền xóa mục này !';
			}
			$this->_redirect($this->view->baseUrl().'/../admin/quangcao');
		}	
		
}
?>