tinyMCE.addI18n({en:{
wprobot:{	
desc : 'Insert WP Robot Content'
}}});
