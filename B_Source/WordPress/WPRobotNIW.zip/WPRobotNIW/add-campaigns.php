<div class="wrap">

<style type="text/css">
.addt {padding:5px;margin-bottom:10px;background:#F5F5F5;border:1px dotted #F0F0F0;}
.addt:hover {background:#F2F2F2;border:1px dotted #d9d9d9;}
div.expld {padding:5px;margin-bottom:10px;background:#fffff0;border:1px dotted #e5dd83;}
div.expld:hover {background:#ffffe5;border:1px dotted #e5db6c;} 
<?php if($options['wpr_help'] == "Yes") {?>
a.tooltip {background:#ffffff;font-weight:bold;text-decoration:none;padding:2px 6px;}
a.tooltip:hover {background:#ffffff; text-decoration:none;} /*BG color is a must for IE6*/
a.tooltip span {display:none;font-weight:normal; padding:2px 3px; margin-left:8px; width:230px;}
a.tooltip:hover span{display:inline; position:absolute; background:#ffffff; border:1px solid #cccccc; color:#6c6c6c;}
<?php } else {?>
a.tooltip {display:none;}
<?php } ?>
</style>
<script type="text/javascript">
function toggle_visibility(id) {
	var e = document.getElementById(id);
	if(e.style.display == 'block')
		e.style.display = 'none';
	else
		e.style.display = 'block';
}

</script>

<h2><?php if( $_GET['edit'] ) {_e("Edit Campaign","wprobot");} else { _e("Add New Campaign","wprobot");} ?></h2>

<form method="post" id="wpr_new">

	<?php if( $_GET['edit'] ) { ?>
		<input name="edit" type="hidden" value="<?php echo $_GET['edit']; ?>"/>
	<?php } ?>

	<div style="width:70%;position:relative;">		
	
		<p class="submit" style="float:right;margin:0;padding: 10px 0;">
            <input class="button-primary" type="submit" name="wpr_add" value="<?php if(!$_GET["edit"]) {_e("Create Campaign","wprobot");} else {_e("Update Campaign","wprobot");} ?>" />
        </p>
        
	<p><?php _e("Name your campaign:","wprobot") ?> <input name="name" type="text" value="<?php echo $_POST['name'];?>"/><!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('The name is only used to organize your campaigns. It does not affect posting.',"wprobot") ?></span></a></p>
		
	<h3 style="text-transform:uppercase;border-bottom: 1px solid #ccc;"><?php _e("Main Settings","wprobot") ?></h3>

	<table class="addt" width="100%">
		
		<tr>
			<td colspan="2">
				<b><?php _e("RSS Feeds","wprobot") ?></b> <?php _e("(one per line)","wprobot") ?>
				<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Enter one RSS Feed URL per line. The feeds correspond to the keyword and category on the same line, i.e. the RSS Feed on line 2 belongs to the keyword and category on line 2 in the respective fields.<br/><br/><b>Keywords are optional!</b> They can be used to also post content from other modules in this RSS Campaign and/or filter the content of the RSS feeds.',"wprobot") ?></span></a><br/>
				<textarea name="feeds" rows="5" cols="75"><?php echo $_POST['feeds'];?></textarea>				
			</td>
		</tr>
			
		<tr>
			<td width="50%">
				<b><?php _e("Keywords","wprobot") ?></b> <?php _e("(one per line)","wprobot") ?>
				<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Enter one keyword or phrase per line. For each post one of the keywords will be randomly selected.<br/><br/>You can enclose keywords in double quotes to enable exact search for them.<br/><br/><b>Example</b><br/>Banana<br/>"Wordpress Plugins"<br/>Free Apple Ipods',"wprobot") ?></span></a>
				<br/>
				<textarea name="keywords" rows="5" cols="33"><?php echo stripslashes($_POST['keywords']);?></textarea>
			</td>
			<td valign="top">
				<input size="5" name="multisingle" type="hidden" value="<?php echo $_POST['multisingle']; ?>"/>
				<?php if($_POST['multisingle'] == "multi") {$txt = __("Single","wprobot");} else {$txt = __("Multi","wprobot");} ?>
				<b><?php _e("Categories","wprobot") ?></b> <?php _e("(one per line)","wprobot") ?> <input class="button" type="submit" name="catbut" value="<?php echo $txt; ?>" />
				<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Enter one category per line. Each category will corespond to the keyword on the same line, i.e. the keyword on line 2 will be posted to the category on line 2.<br/><br/>You can also enter a single category instead. Then all posts will be made in this category.<br/><br/><b>Example</b><br/>Banana Category<br/>Wordpress Plugins<br/>Free Apple Ipods',"wprobot") ?> <?php _e("<br/><br/>New: Since WP Robot v3.4 you can also enter multiple comma-separated categories for a single keyword, e.g. enter 'Dogs,Photos' to have posts for the keyword on the same line added to both the 'Dogs' and 'Photos' categories.","wprobot") ?></span></a>
				<br/>
				<?php if($_POST['multisingle'] == "multi") {?>
				<textarea name="categories" rows="5" cols="33"><?php echo stripslashes($_POST['categories']);?></textarea>
				<?php } else {
					echo '<select name="categories">';		
				   	$categories = get_categories('type=post&hide_empty=0');
				   	foreach($categories as $category) {
						if($category->cat_ID == $_POST['categories']) {$sel = " selected";} else {$sel = "";}
				   		echo '<option value="'.$category->cat_ID.'"'.$sel.'>'.$category->cat_name.'</option>';
				   	}
					echo '</select>';		
					}	
				?>
			</td>
		</tr>
		<tr>
			<td>
				<input name="autopost" type="checkbox" value="yes" <?php if ($_POST['autopost'] =='yes') {echo "checked";} ?>/> <?php _e("Post every","wprobot") ?> <input size="5" name="interval" type="text" value="<?php echo $_POST['interval'];?>"/>
					<select name="period">
						<option value="hours" <?php if ($_POST['period'] =='hours') {echo "selected";} ?>><?php _e("Hours","wprobot") ?></option>
						<option value="days" <?php if ($_POST['period'] =='days') {echo "selected";} ?>><?php _e("Days","wprobot") ?></option>
					</select>	
				<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('If enabled Wordpress internal cron functions will be used to run this campaign in the interval you specify.<br/><br/>Alternatively you can disable the option and then set up a unix cron-job to autopost this campaign after creating it.',"wprobot") ?></span></a>		
			</td>
			<td>
				<input name="createcats" type="checkbox" value="yes" <?php if ($_POST['createcats'] =='yes') {echo "checked";} ?>/> <?php _e("Create categories if not existing","wprobot") ?>
			</td>
		</tr>		
	</table>
	
	<h3 style="text-transform:uppercase;border-bottom: 1px solid #ccc;"><?php _e("Optional Settings","wprobot") ?></h3>	
	
	<table class="addt" width="100%">
		<tr>
			<td width="50%">
				<strong><?php _e("Replace Keywords","wprobot") ?></strong> <?php _e("(one per line)","wprobot") ?>
				<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Use this option to replace certain keywords in this campaigns posts with other keywords or links.<br/><br/><b>Syntax</b><br/>Keyword|Replace With|Chance<br/><br/><b>Example</b><br/>Wordpress|Joomla|50<br/>Free Apple Ipods|Expensive Apple Ipods|100<br/>Wordpress Plugins|< a href=link>Link text< /a>|25',"wprobot") ?></span></a><br/>
				<textarea name="replace" rows="3" cols="33"><?php echo stripslashes($_POST['replace']);?></textarea>
			</td>	
			<td>
				<strong><?php _e("Exclude Keywords","wprobot") ?></strong> <?php _e("(one per line)","wprobot") ?>
				<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('If any one of the keywords you enter here is found in a post it will be skipped and not created. Because of that make sure not to enter common words or phrases here.<br/><br/><b>Example</b><br/>exclude keyword 1<br/>keyword 2',"wprobot") ?></span></a><br/>
				<textarea name="exclude" rows="3" cols="33"><?php echo stripslashes($_POST['exclude']);?></textarea>
			</td>			
		</tr>
				
		<tr>
			<td width="100%" colspan="2">
			<b><?php _e("Featured Image","wprobot") ?></b>
			<!--Tooltip--><a class="tooltip" target="_blank" href="http://wprobot.net/documentation/#634">?<span><?php _e('<b>Important:</b> For this setting to work "Save Images to Server:" on the Options page has to be activated and your Wordpress "uploads" folder needs to be writeable (chmod 666)!',"wprobot") ?> <?php _e("<br/><br/><b>Warning:</b> Only enable if your theme actually supports WP post thumbnails or you get duplicate posts!","wprobot") ?></span></a><br/>
			<p style="margin:3px 0;">
			<input type="checkbox" name="wpr_postthumbs" value="1" <?php if($_POST["wpr_postthumbs"] == 1) {echo "checked";} ?>/> <?php _e("Attempt to add featured image / post thumbnail to each created post if image is available. (<b>Warning:</b> Only enable if your theme actually supports WP post thumbnails or you get duplicate posts!)","wprobot") ?>
			</p>
			</td>
		</tr>		
		
		
		<tr>
			<td width="100%" colspan="2">
			<b><?php _e("Custom Fields","wprobot") ?></b>
			<!--Tooltip--><a class="tooltip" target="_blank" href="http://wprobot.net/documentation/#634">?<span><?php _e('This custom field will be added to every post. Premium templates often use custom fields to populate thumbnails but there are many other possible uses as well.<br/><br/><b>Click here to see a list of all available Value Tags</b><br/><br/><strong>Use the "+" button to add an additional custom field.</strong>',"wprobot") ?></span></a><br/>

			<?php if(!$_POST['cfnum']) {$_POST['cfnum'] = 1;} ?>
			<input size="5" name="cfnum" type="hidden" value="<?php echo $_POST['cfnum']; ?>"/>
			
			<?php for ($i = 1; $i <= $_POST['cfnum']; $i++) { ?>

			<strong><?php echo $i; ?>.</strong>
			<?php _e("Name:","wprobot") ?> <input name="cf_name<?php echo $i; ?>" type="text" value="<?php echo $_POST["cf_name$i"];?>"/> 
			<?php _e("Value:","wprobot") ?> <input name="cf_value<?php echo $i; ?>" type="text" value="<?php echo $_POST["cf_value$i"];?>"/>
			<?php if($i == $_POST['cfnum']) {?>
				<input class="button" type="submit" name="wpr_cf_add" value="+" />
				<?php if($_POST['cfnum'] > 1) {?> <input class="button" type="submit" name="wpr_cf_remove" value="-" /><?php } ?>		
			<?php } ?>			 			
			<br/>
			<?php } ?>			
			</td>
		</tr>
	
		<tr>
			<td width="50%">
			<b><?php _e("Rewriter","wprobot") ?></b>
			<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Important: You also need to activate the rewriting service of your choice on the WP Robot Options page.',"wprobot") ?></span></a><br/>			
			<input type="checkbox" name="wpr_rewriter" value="1" <?php if($_POST["wpr_rewriter"] == 1) {echo "checked";} ?>/> <?php _e("Activate rewriting for this campaign.","wprobot") ?>			
			</td>
			
			<td width="50%">
			<b><?php _e("Author ID","wprobot") ?></b>
			<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Enter the ID of the author you want to use for posts by this campaign. If left empty the default settings from the WP Robot Options screen will be used.',"wprobot") ?></span></a><br/>
			<input name="wpr_author" type="text" value="<?php echo $_POST['wpr_author'];?>"/>
			</td>			
		</tr>		

		
		<tr>
			<td width="50%">
			<b><?php _e("Start","wprobot") ?></b>
			<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Delays the first post of this campaign by the amount you enter. Zero means the first post will be created immediatelly after adding the campaign.',"wprobot") ?></span></a><br/>
			<?php _e("Create first post in","wprobot") ?> <input size="3" name="delaystart" type="text" value="<?php echo $_POST['delaystart'];?>"/> <?php _e("hours.","wprobot") ?>
			</td>
			
			<td>
			<b><?php _e("New Post Status","wprobot") ?></b>
			<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('New posts by this campaign can either be published immediatelly or be added as drafts, so you can review them before going live. This overrides the global post status setting on the options page!',"wprobot") ?></span></a><br/>
				<select name="wpr_poststatus" id="wpr_poststatus">
					<option value="default" <?php if ($_POST['wpr_poststatus']=='default') {echo 'selected';} ?>><?php _e("default","wprobot") ?></option>				
					<option value="published" <?php if ($_POST['wpr_poststatus']=='published') {echo 'selected';} ?>><?php _e("published","wprobot") ?></option>
					<option value="draft" <?php if ($_POST['wpr_poststatus']=='draft') {echo 'selected';} ?>><?php _e("draft","wprobot") ?></option>
				</select>
			</td>		
		</tr>	

		<tr>
			<td width="50%">
			<b><?php _e("Custom Post Type","wprobot") ?></b>
			<!--Tooltip--><a class="tooltip" href="#">?<span><?php _e('Custom post types are a new Wordpress feature used by some themes to categorize the content into different types. <b>Warning:</b> Only enter something here if you are sure your theme supports a custom post type of this name or you wont see the content generated by this campaign!',"wprobot") ?></span></a><br/>
			<input size="30" name="wpr_posttype" type="text" value="<?php echo $_POST['wpr_posttype'];?>"/>
			</td>
			
			<td>
			</td>		
		</tr>			
	</table>	
			
	<p class="submit" style="margin:0;padding: 10px 0;"><input class="button-primary" type="submit" name="wpr_add" value="<?php if(!$_GET["edit"]) {_e("Create Campaign","wprobot");} else {_e("Update Campaign","wprobot");} ?>" /></p>
	<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	</div>
	
</form>