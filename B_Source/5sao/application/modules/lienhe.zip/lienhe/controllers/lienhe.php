<?php
class Lienhe extends NIW_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->module=strtolower(get_class());
		$this->load->model('Mlienhe');
		$this->setLang();
		$this->loadLang();
	}
	
	function loadLang()
	{
		$lang=$this->session->userdata('lang');
		if ($lang=='vn')
		{
			$this->lang->load('5sao','vietnamese');
		}
		else $this->lang->load('5sao','english');
	}
	
	function index()
	{
		$data['list_gioithieumenu']=$this->Mlienhe->getListFull('gioithieu');
		$data['categories']=$this->Mlienhe->getListByColumn('danhmuc','parent_id','0');
		
		$data['title']='5saoviet | Liên hệ';
		$data['lang']=$this->session->userdata('lang');
		$data['module']=$this->module;
		$data['page']='vlienhe';
		$this->load->view('front/container',$data);
	}
}