<html>
<head>
<title>Error</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="error/error.css">
</head>
<body>
	<div id="content">
		<h1>Lỗi</h1>
		<?php echo $message; ?>
	</div>
</body>
</html>