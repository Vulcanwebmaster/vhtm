<?$path = 'system/application/views/theme/admin/vnit/images/header/';?>
<div style="width: 50%;">
<div id="cpanel">
    <div class="icon">
        <a href="<?=base_url()?>noidung/themmoi">
            <img src="<?=base_url().$path?>icon-48-article-add.png" alt="">
            <span>Thêm mới bài viết</span>
        </a>
    </div>
    <div class="icon">
        <a href="<?=base_url()?>noidung/theloai">
            <img src="<?=base_url().$path?>icon-48-article.png" alt="">
            <span>Thể loại</span>
        </a>
    </div>    
    <div class="icon">
        <a href="<?=base_url()?>noidung/danhmuc">
            <img src="<?=base_url().$path?>icon-48-category.png" alt="">
            <span>Chuyên mục</span>
        </a>
    </div>    
    <div class="icon">
        <a href="<?=base_url()?>quanlyfile">
            <img src="<?=base_url().$path?>icon-48-media.png" alt="">
            <span>Tài nguyên</span>
        </a>
    </div>

    <div class="icon">
        <a href="<?=base_url()?>thanhviens">
            <img src="<?=base_url().$path?>icon-48-user.png" alt="">
            <span>Thành viên</span>
        </a>
    </div>    
    <div class="icon">
        <a href="">
            <img src="<?=base_url().$path?>icon-48-themes.png" alt="">
            <span>Giao diện</span>
        </a>
    </div>     
    <div class="icon">
        <a href="<?=base_url()?>lienhe/danhsach">
            <img src="<?=base_url().$path?>icon-48-contacts.png" alt="">
            <span>Liên hệ</span>
        </a>
    </div> 
    <div class="icon">
        <a href="">
            <img src="<?=base_url().$path?>icon-48-banner-categories.png" alt="">
            <span>Quảng cáo</span>
        </a>
    </div>   
    <div class="icon">
        <a href="<?=base_url()?>cauhinh">
            <img src="<?=base_url().$path?>icon-48-config.png" alt="">
            <span>Cấu hình</span>
        </a>
    </div>   
    <div class="icon">
        <a href="<?=base_url()?>cauhinh/hethong">
            <img src="<?=base_url().$path?>icon-48-info.png" alt="">
            <span>Hệ thống</span>
        </a>
    </div>         
</div>
</div>


