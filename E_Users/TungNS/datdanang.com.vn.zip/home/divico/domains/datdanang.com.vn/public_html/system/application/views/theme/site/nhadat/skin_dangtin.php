<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="google-site-verification" content="0mef_3XMZ9fPQCVD22aC7EbLOD7HfcP7qkuxBh9NY4k" />
<title><?=$title?></title>
<meta name="description" content="<?=$this->setting_library->setting['site_description']?>">
<meta name="keywords" content="<?=$this->setting_library->setting['site_keywords']?>">
<meta name="generator" content="Phan Gia Huy Co., Ltd. - info@phangiahuy.com, www.phangiahuy.com, 0905211588" /> 
<link rel="stylesheet" type="text/css" href="<?=base_url()?>system/application/views/theme/site/<?=$this->site_library->get_default_template()?>/css/dinhviet.css">

<link rel="stylesheet" type="text/css" href="<?=base_url()?>system/application/views/theme/system/css/system.css">
<script type="text/javascript" src="<?=base_url()?>system/application/views/theme/system/js/jquery-core.js"></script>


</head>
<body>
<div id="header_top">
    <div id="wrapper" class="head">
       <div id="header">
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="980" height="140">
		  <param name="movie" value="<?=base_url()?>skins/banner.swf" />
		  <param name="quality" value="high" />
		  <param name="allowScriptAccess" value="always" />
		  <param name="wmode" value="transparent">
		     <embed src="<?=base_url()?>skins/banner.swf"
		      quality="high"
		      type="application/x-shockwave-flash"
		      WMODE="transparent"
		      width="980"
		      height="140"
		      pluginspage="http://www.macromedia.com/go/getflashplayer"
		      allowScriptAccess="always" />
		</object>

          
       </div>
       <div id="header_menu">
           <div class="menu">
           <?=$this->load->view('theme/site/nhadat/html/menu')?>
           </div>
            <div class="dangky">
                
            </div>       
       </div> 
       <div id="header_sub"></div>
    </div>

</div>

<div id="wrapper" style="background-color: #FFFFFF;padding-top: 10px;overflow: hidden;">

    <div style="width: 300px;float: left;">
         
    </div>
    <div style="width: 670px;float: right;margin-bottom: 10px;">
        <?if($this->session->flashdata('message')){
            echo '<div class="message">'.$this->session->flashdata('message').'</div>';
        }if($this->session->flashdata('error')){
            echo '<div class="error">'.$this->session->flashdata('error').'</div>';
        }if($this->session->flashdata('notes')){
            echo '<div class="notes">'.$this->session->flashdata('notes').'</div>';
        }

        ?>    
         <?=$this->load->view($page)?>    
    </div> 
    <?=$this->load->view('theme/site/nhadat/html/footer')?>     
</div>

</body>
</html>
        
