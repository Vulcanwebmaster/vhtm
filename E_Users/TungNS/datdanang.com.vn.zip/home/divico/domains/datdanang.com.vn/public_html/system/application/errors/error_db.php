<html>
<head>
<title>Database Error</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="error/error.css">
</head>
<body>
	<div id="content">
		<h1>Lỗi cơ sở dữ liệu</h1>
		<?php echo $message; ?>
	</div>
</body>
</html>