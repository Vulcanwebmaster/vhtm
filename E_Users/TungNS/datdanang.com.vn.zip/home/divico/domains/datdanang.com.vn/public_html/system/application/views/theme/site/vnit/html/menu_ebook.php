
<div id="menu">
    <ul class="menu">
        <li><a href="<?=base_url()?>"><span>Trang chủ</span></a></li>
        <li><a href="<?=base_url()?>"><span>Đăng ký</span></a></li>
        <li><a href="<?=base_url()?>"><span>Hướng dẫn</span></a></li>
        <li><a href="<?=base_url()?>"><span>Giới thiệu</span></a></li>
        <li><a href="<?=base_url()?>"><span>Liên hệ</span></a></li>
        
        
    </ul>
</div>