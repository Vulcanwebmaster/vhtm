<?php
  $lang['modules_name_error'] ='Tên Mô-đun không được để trống';
  $lang['modules_name'] ='Tên Mô-đun';
?>
