<?php
  class upload_library{
      function __construct(){
          $this->CI = get_instance();
      }

  }
?>
