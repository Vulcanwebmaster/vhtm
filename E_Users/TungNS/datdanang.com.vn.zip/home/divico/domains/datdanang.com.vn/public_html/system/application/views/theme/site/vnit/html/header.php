<div class="headtop">
     <div class="logo">
        <img src="<?=base_url()?>skins/tintuc.png" alt="">  
     </div>
     <div class="adv">
        <?=$this->load->view('modules/tnd_app/index')?> 
        <?=$this->load->view('modules/tnd_quangcao/tintuc_banner')?>
     </div>
</div>

<div class="menu ">
      <?=$this->load->view('modules/tnd_menutintuc/index')?>
</div>