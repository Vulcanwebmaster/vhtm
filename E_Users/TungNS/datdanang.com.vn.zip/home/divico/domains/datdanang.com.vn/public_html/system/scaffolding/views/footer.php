
</div>

<div id="footer">
<p><a href="http://codeigniter.com/">CodeIgniter</a>, by <a href="http://www.EllisLab.com">EllisLab</a> -  Version <?php echo CI_VERSION ?></p>
<p>Page rendered in {elapsed_time}</p>
</div>

</body>
</html>