<ul id="menu">
<li class="node"><a href="#" class="">Trang chủ</a>
    <ul>
        <li><a href="<?=base_url()?>admin/quantri" class="icon-16-cpanel">Bảng điều khiển</a></li>

        <li><a href="<?=base_url()?>cauhinh" class="icon-16-config">Cấu hình</a></li>

        <li><a href="<?=base_url()?>cauhinh/hethong" class="icon-16-info">Thông tin hệ thống</a></li>

        <li><a href="<?=base_url()?>admin/logout" class="icon-16-logout">Thoát</a></li>
    </ul>
</li>
<li class="node"><a href="#" class="">Thành viên</a>
    <ul>
        <li><a href="<?=base_url()?>thanhviens" class="icon-16-user">Quản lý thành viên</a></li>

        <li><a href="<?=base_url()?>thanhviens/themmoi" class="icon-16-newuser">Thêm mới thành viên</a></li>
        <li><a href="<?=base_url()?>" class="icon-16-newgroup">Thêm mới nhóm</a></li>

    </ul>
</li>

<li class="node"><a href="#" class="">Nội dung</a>
    <ul>
        <li><a href="<?=base_url()?>noidung/baiviet" class="icon-16-article">Quản lý bài viết</a></li>
        <li><a href="<?=base_url()?>noidung/theloai" class="icon-16-category">Quản lý Thể loại</a></li>
        <li><a href="<?=base_url()?>noidung/danhmuc" class="icon-16-featured">Quản lý chuyên mục</a></li>

        <li><a href="<?=base_url()?>noidung/themmoi" class="icon-16-article">Thêm mới bài viết</a></li> 
        <li><a href="<?=base_url()?>noidung/themtheloai" class="icon-16-newarticle">Thêm mới thể loại</a></li>
        <li><a href="<?=base_url()?>noidung/themdanhmuc" class="icon-16-newcategory">Thêm mới chuyên mục</a></li>

        <li><a href="<?=base_url()?>quanlyfile" class="icon-16-media">Quản lý tài nguyên</a></li>
    </ul>
</li>
<li class="node"><a href="#" class="">Ứng dụng</a>
    <ul>
        <li class="node"><a href="<?=base_url()?>nhadats/index" class="icon-16-contact">Nhà đất</a>
            <!--
            <ul class="menu-component" id="menu-contacts">
                <li><a href="<?=base_url()?>nhadats/danhsach/0" class="icon-16-contact">Tin đang chờ duyệt</a></li>
                <li><a href="<?=base_url()?>nhadats/danhsach/1" class="icon-16-contact-cat">Tin đã được Duyệt</a></li>
            </ul>
            -->
        </li>    
        <li class="node"><a href="<?=base_url()?>quangcao/danhsach" class="icon-16-banners">Quảng cáo</a>
        </li>
        <li class="node"><a href="<?=base_url()?>lienhe/nhomlienhe" class="icon-16-contact">Liên hệ</a>
            <ul class="menu-component" id="menu-contacts">
                <li><a href="<?=base_url()?>lienhe/nhomlienhe" class="icon-16-contact">Liên hệ</a></li>
                <li><a href="<?=base_url()?>lienhe/danhsach" class="icon-16-contact-cat">Thông tin liên hệ</a></li>
            </ul>
        </li>

    </ul>
</li>

</ul>