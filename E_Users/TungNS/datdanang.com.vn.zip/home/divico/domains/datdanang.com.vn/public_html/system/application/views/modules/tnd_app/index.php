<div class="appdendomdom">
    <ul>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('#','Rao vặt')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('phim.html','Phim')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('nhac.html','Nhạc')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('tv.html','Truyền hình')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('anhdep.html','Ảnh')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('tailieu.html','Tài liệu')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('diendan.html','Diễn đàn')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('tintuc.html','Tin tức')?></li>
        <li><img src="<?=base_url()?>skins/itemsmall.png" alt=""><?=anchor('','Đèn Đom Đóm')?></li>
    </ul>
</div>