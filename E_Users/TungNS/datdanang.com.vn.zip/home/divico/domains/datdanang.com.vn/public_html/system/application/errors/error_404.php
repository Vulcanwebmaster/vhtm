<html>
<head>
<title>404 Page Not Found</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="error/error.css">

</head>
<body>
    <center>
    <div class="header"></div>
	<div id="content">
		<h1>Lỗi 404. Không tìm thấy trang</h1>
		Trang bạn vừa yêu cầu không thể tìm thấy. Xin vui lòng thử lại
	</div>
    </center>
</body>
</html>