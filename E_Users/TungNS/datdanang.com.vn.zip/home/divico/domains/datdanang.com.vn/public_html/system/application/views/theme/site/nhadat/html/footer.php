<div id="footer">
       <div>Copyright © 2010 Dinh Viet Land. </div>
		<div><b>CÔNG TY CỔ PHẦN ĐẦU TƯ & XÂY LẮP ĐỈNH VIỆT.</b></div>
	   <div>Trụ sở: 613 Lê Thanh Nghị - Quận Hải Châu - Thành phố Đà Nẵng <br />
Tel: 0511.3623458 - Fax: 0511.3623454 <br />
Email: info@divico.com.vn - Website: www.divico.com.vn - www.datdanang.com.vn</div>
       <div style='float: right;'><i>Designed by <a href="http://www.phangiahuy.com" title='Thiet ke website chuyen nghiep' target='_blank' style='color: #F3F3F3; font-weight: bold;'> Phan Gia Huy Co., Ltd </a></i></div>
</div>
