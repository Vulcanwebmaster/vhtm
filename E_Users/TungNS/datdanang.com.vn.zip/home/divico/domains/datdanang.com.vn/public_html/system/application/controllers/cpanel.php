<?php
  class cpanel extends Controller{
      protected $_templates;
      function cpanel(){
          parent::model();
      }
  }
?>
