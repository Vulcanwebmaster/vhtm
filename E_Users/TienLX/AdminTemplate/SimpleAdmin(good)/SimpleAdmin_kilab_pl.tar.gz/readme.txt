AdminPanel by Pawel 'kilab' Balicki
downloaded from http://kilab.pl

LICENSE:
================================================
	
	This work is licensed under a Creative Commons 3.0
	
	You Can for free:
		*to Share - to copy, distribute and transmit the work 
		*to Remix - to adapt the work 
		*to make commercial use of the work
	
	
ICONS SET:
================================================

	Icons used in template donloaded from:
		* http://pc.de/icons/
		* http://www.famfamfam.com/
